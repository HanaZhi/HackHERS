(function () {
  'use strict';

  // ----- i18n: get translation by path (e.g. "nav.affected"). Fallback to English. -----
  function getByPath(obj, path) {
    if (!obj || typeof path !== 'string') return undefined;
    var keys = path.split('.');
    for (var i = 0; i < keys.length; i++) {
      if (obj == null || typeof obj !== 'object') return undefined;
      obj = obj[keys[i]];
    }
    return typeof obj === 'string' ? obj : undefined;
  }

  function getTranslation(locale, path) {
    var T = window.TRANSLATIONS;
    if (!T || !T[locale]) locale = 'en';
    var value = getByPath(T[locale], path);
    if (value != null) return value;
    if (locale === 'en') return path;
    return getByPath(T.en, path) || path;
  }

  function applyTranslations(locale) {
    if (!window.TRANSLATIONS) return;
    var supported = ['en', 'es', 'zh_TW'];
    if (supported.indexOf(locale) === -1) locale = 'en';

    document.querySelectorAll('[data-i18n]').forEach(function (el) {
      var key = el.getAttribute('data-i18n');
      var text = getTranslation(locale, key);
      if (text != null) el.textContent = text;
    });
    document.querySelectorAll('[data-i18n-html]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-html');
      var html = getTranslation(locale, key);
      if (html != null) el.innerHTML = html;
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-placeholder');
      var text = getTranslation(locale, key);
      if (text != null) el.placeholder = text;
    });
    document.querySelectorAll('[data-i18n-aria-label]').forEach(function (el) {
      var key = el.getAttribute('data-i18n-aria-label');
      var text = getTranslation(locale, key);
      if (text != null) el.setAttribute('aria-label', text);
    });

    var htmlLang = locale === 'zh_TW' ? 'zh-Hant' : locale === 'es' ? 'es' : 'en';
    document.documentElement.lang = htmlLang;
    document.body.classList.remove('locale-en', 'locale-es', 'locale-zh_TW');
    document.body.classList.add('locale-' + locale);
  }

  function getStoredLocale() {
    try {
      var stored = localStorage.getItem('know-your-rights-lang');
      if (stored && (stored === 'en' || stored === 'es' || stored === 'zh_TW')) return stored;
    } catch (_) {}
    return null;
  }

  function detectBrowserLanguage() {
    var lang = (navigator.language || navigator.userLanguage || '').toLowerCase();
    if (lang.indexOf('es') === 0) return 'es';
    if (lang.indexOf('zh') === 0) return 'zh_TW';
    return 'en';
  }

  var currentLocale = getStoredLocale() || detectBrowserLanguage();

  // ----- Language toggle (header): update UI instantly, persist in localStorage -----
  var langBtns = document.querySelectorAll('.header-lang__btn');
  function setActiveLang(locale) {
    langBtns.forEach(function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-lang') === locale ? 'true' : 'false');
    });
  }

  langBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var lang = btn.getAttribute('data-lang');
      if (lang === 'zh') lang = 'zh_TW';
      currentLocale = lang;
      setActiveLang(lang);
      try { localStorage.setItem('know-your-rights-lang', lang); } catch (_) {}
      applyTranslations(lang);
      if (typeof refreshQuiz === 'function') refreshQuiz();
    });
  });

  function onPageReady() {
    setActiveLang(currentLocale);
    applyTranslations(currentLocale);
    if (typeof refreshQuiz === 'function') refreshQuiz();
    // Keep reload at top: clear hash and scroll to top so we don't land on #affected etc.
    if (window.location.hash) {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
      window.scrollTo(0, 0);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      onPageReady();
    });
  } else {
    onPageReady();
  }

  // ----- Nav (mobile) -----
  var nav = document.querySelector('.nav');
  var navToggle = document.querySelector('.nav-toggle');
  if (navToggle && nav) {
    navToggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
  }

  // ----- Practice quiz (inline, no iframe). Scenario prompts/choices/feedback from translations. -----
  var quizRoot = document.getElementById('quiz-root');
  var quizState = { scenarioIndex: 0, selected: null, showFinal: false };
  var Q = [
    { prompt: 'quiz.s0Prompt', choices: [
      { label: 'quiz.s0c0Label', feedback: 'quiz.s0c0Fb', correct: false },
      { label: 'quiz.s0c1Label', feedback: 'quiz.s0c1Fb', correct: true },
      { label: 'quiz.s0c2Label', feedback: 'quiz.s0c2Fb', correct: false },
    ], displayOrder: [1, 0, 2] },
    { prompt: 'quiz.s1Prompt', choices: [
      { label: 'quiz.s1c0Label', feedback: 'quiz.s1c0Fb', correct: false },
      { label: 'quiz.s1c1Label', feedback: 'quiz.s1c1Fb', correct: true },
      { label: 'quiz.s1c2Label', feedback: 'quiz.s1c2Fb', correct: false },
    ], displayOrder: [0, 2, 1] },
    { prompt: 'quiz.s2Prompt', choices: [
      { label: 'quiz.s2c0Label', feedback: 'quiz.s2c0Fb', correct: false },
      { label: 'quiz.s2c1Label', feedback: 'quiz.s2c1Fb', correct: true },
      { label: 'quiz.s2c2Label', feedback: 'quiz.s2c2Fb', correct: false },
    ], displayOrder: [0, 1, 2] },
  ];
  function esc(s) {
    if (s == null) return '';
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function refreshQuiz() {
    if (!quizRoot || !window.TRANSLATIONS) return;
    var locale = currentLocale;
    if (!window.TRANSLATIONS[locale]) locale = 'en';
    var t = function (key) { return getTranslation(locale, key) || key; };
    var s = quizState;
    var html = '';
    if (s.showFinal) {
      html = '<div class="quiz-final">' +
        '<h3 class="quiz-final-heading">' + esc(t('quiz.finalHeading')) + '</h3>' +
        '<p class="quiz-final-body">' + esc(t('quiz.finalBody')) + '</p>' +
        '<div class="quiz-final-actions">' +
        '<a href="https://www.aila.org/library/client-flyer-know-your-rights" target="_blank" rel="noopener" class="quiz-btn quiz-btn-primary">' + esc(t('quiz.reviewRights')) + '</a> ' +
        '<button type="button" class="quiz-btn quiz-btn-secondary" data-quiz-startover>' + esc(t('quiz.startOver')) + '</button>' +
        '</div></div>';
    } else if (s.selected != null) {
      var sc = Q[s.scenarioIndex];
      var ch = sc.choices[s.selected];
      var feedbackLabel = ch.correct ? t('quiz.goodChoice') : t('quiz.whatToKnow');
      var isLast = s.scenarioIndex >= Q.length - 1;
      html = '<p class="quiz-progress">' + esc(t('quiz.scenarioOf')) + ' ' + (s.scenarioIndex + 1) + ' ' + esc(t('quiz.of')) + ' ' + Q.length + '</p>' +
        '<p class="quiz-prompt">' + esc(t(sc.prompt)) + '</p>' +
        '<div class="quiz-feedback ' + (ch.correct ? 'quiz-feedback-correct' : 'quiz-feedback-know') + '" role="status">' +
        '<p class="quiz-feedback-label">' + esc(feedbackLabel) + '</p>' +
        '<p class="quiz-feedback-text">' + esc(t(ch.feedback)) + '</p></div>' +
        '<button type="button" class="quiz-btn quiz-btn-primary" data-quiz-next>' + esc(isLast ? t('quiz.finish') : t('quiz.tryAnother')) + '</button>';
    } else {
      var sc = Q[s.scenarioIndex];
      var order = sc.displayOrder || [0, 1, 2];
      html = '<p class="quiz-progress">' + esc(t('quiz.scenarioOf')) + ' ' + (s.scenarioIndex + 1) + ' ' + esc(t('quiz.of')) + ' ' + Q.length + '</p>' +
        '<p class="quiz-prompt">' + esc(t(sc.prompt)) + '</p>' +
        '<ul class="quiz-choices" role="group">';
      order.forEach(function (idx) {
        var c = sc.choices[idx];
        html += '<li><button type="button" class="quiz-choice-btn" data-quiz-choice="' + idx + '">' + esc(t(c.label)) + '</button></li>';
      });
      html += '</ul>';
    }
    quizRoot.innerHTML = html;
  }
  if (quizRoot) {
    quizRoot.addEventListener('click', function (e) {
      var target = e.target;
      if (target.getAttribute('data-quiz-choice') != null) {
        quizState.selected = parseInt(target.getAttribute('data-quiz-choice'), 10);
        refreshQuiz();
      } else if (target.getAttribute('data-quiz-next') != null) {
        if (quizState.scenarioIndex >= Q.length - 1) {
          quizState.showFinal = true;
          quizState.scenarioIndex = 0;
          quizState.selected = null;
        } else {
          quizState.scenarioIndex++;
          quizState.selected = null;
        }
        refreshQuiz();
      } else if (target.getAttribute('data-quiz-startover') != null) {
        quizState.scenarioIndex = 0;
        quizState.selected = null;
        quizState.showFinal = false;
        refreshQuiz();
      }
    });
  }

  // ----- Document Safety Checker -----
  var docOptions = {
    passport: { level: 'strong' },
    greencard: { level: 'strong' },
    i94: { level: 'some' },
    stamped: { level: 'some' },
    ead: { level: 'some' },
    i797: { level: 'some' },
    stateid: { level: 'id' }
  };

  var resultTextKeys = {
    passport: 'safetyCheck.resultPassport',
    greencard: 'safetyCheck.resultGreencard',
    i94: 'safetyCheck.resultI94',
    stamped: 'safetyCheck.resultStamped',
    ead: 'safetyCheck.resultEad',
    i797: 'safetyCheck.resultI797',
    stateid: 'safetyCheck.resultStateId'
  };

  function getResultLabelKey(level) {
    if (level === 'strong') return 'safetyCheck.resultLabelStrong';
    if (level === 'some') return 'safetyCheck.resultLabelSome';
    return 'safetyCheck.resultLabelId';
  }

  function refreshDocResult(locale) {
    var result = document.getElementById('doc-result');
    var protection = document.getElementById('doc-result-protection');
    var textEl = document.getElementById('doc-result-text');
    if (!result || result.hidden || !protection || !textEl) return;
    var btn = document.querySelector('.doc-option[aria-selected="true"]');
    if (!btn || !btn.dataset.doc) return;
    var key = btn.dataset.doc;
    var data = docOptions[key];
    if (!data) return;
    var loc = locale != null ? locale : currentLocale;
    protection.textContent = getTranslation(loc, getResultLabelKey(data.level));
    protection.className = 'doc-result-protection protection-' + data.level;
    textEl.textContent = getTranslation(loc, resultTextKeys[key]);
  }

  var docList = document.getElementById('doc-selector-list');
  var docResult = document.getElementById('doc-result');
  var docResultProtection = document.getElementById('doc-result-protection');
  var docResultText = document.getElementById('doc-result-text');

  if (docList && docResult && docResultProtection && docResultText) {
    docList.addEventListener('click', function (e) {
      var btn = e.target.closest('.doc-option');
      if (!btn || !btn.dataset.doc) return;
      var key = btn.dataset.doc;
      var data = docOptions[key];
      if (!data) return;

      docList.querySelectorAll('.doc-option').forEach(function (o) {
        o.setAttribute('aria-selected', o === btn ? 'true' : 'false');
      });
      docResultProtection.textContent = getTranslation(currentLocale, getResultLabelKey(data.level));
      docResultProtection.className = 'doc-result-protection protection-' + data.level;
      docResultText.textContent = getTranslation(currentLocale, resultTextKeys[key]);
      docResult.hidden = false;
      docResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  }

  // Refresh document result when language changes (so result panel shows in selected language)
  var _applyTranslations = applyTranslations;
  applyTranslations = function (locale) {
    _applyTranslations(locale);
    refreshDocResult(locale);
  };

  // ----- Emergency panic button & modal (no data collection; client-side only; no logging) -----
  var emergencyBtn = document.getElementById('emergency-btn');
  var emergencyOverlay = document.getElementById('emergency-overlay');
  var emergencyClose = document.getElementById('emergency-close');
  var emergencyModal = document.getElementById('emergency-modal');
  var mainContent = document.querySelector('main');

  function getEmergencyFocusables() {
    if (!emergencyModal) return [];
    var nodes = emergencyModal.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
    return Array.prototype.filter.call(nodes, function (el) {
      return el.offsetParent !== null && !el.disabled;
    });
  }

  function openEmergencyModal() {
    if (!emergencyOverlay || !emergencyClose) return;
    emergencyOverlay.hidden = false;
    document.body.classList.add('emergency-modal-open');
    if (mainContent) mainContent.setAttribute('aria-hidden', 'true');
    emergencyClose.focus();
    document.addEventListener('keydown', onEmergencyKeydown);
  }

  function closeEmergencyModal() {
    if (!emergencyOverlay) return;
    emergencyOverlay.hidden = true;
    document.body.classList.remove('emergency-modal-open');
    if (mainContent) mainContent.removeAttribute('aria-hidden');
    if (emergencyBtn) emergencyBtn.focus();
    document.removeEventListener('keydown', onEmergencyKeydown);
  }

  function onEmergencyKeydown(e) {
    if (e.key === 'Escape') {
      closeEmergencyModal();
      e.preventDefault();
      return;
    }
    if (e.key !== 'Tab') return;
    var focusables = getEmergencyFocusables();
    if (focusables.length === 0) return;
    var first = focusables[0];
    var last = focusables[focusables.length - 1];
    if (e.shiftKey) {
      if (document.activeElement === first) {
        last.focus();
        e.preventDefault();
      }
    } else {
      if (document.activeElement === last) {
        first.focus();
        e.preventDefault();
      }
    }
  }

  if (emergencyBtn && emergencyOverlay) {
    emergencyBtn.addEventListener('click', function () {
      openEmergencyModal();
    });
  }
  if (emergencyClose) {
    emergencyClose.addEventListener('click', closeEmergencyModal);
  }
  if (emergencyOverlay) {
    emergencyOverlay.addEventListener('click', function (e) {
      if (e.target === emergencyOverlay) closeEmergencyModal();
    });
  }

  // ----- Rights card: client-side print only; no data stored or sent. -----
  var emergencyPrintCardBtn = document.getElementById('emergency-print-card-btn');
  function openRightsCardPrint() {
    var locale = currentLocale;
    if (!window.TRANSLATIONS || !window.TRANSLATIONS[locale]) locale = 'en';
    var T = window.TRANSLATIONS[locale];
    var rc = T && T.rightsCard;
    if (!rc) rc = window.TRANSLATIONS.en.rightsCard;
    var title = (rc && rc.title) ? String(rc.title) : 'Know Your Rights Card';
    var subtitle = (rc && rc.subtitle) ? String(rc.subtitle) : 'Keep this card. Do not include personal identifying information.';
    var line1 = (rc && rc.line1) ? String(rc.line1) : 'I choose to remain silent.';
    var line2 = (rc && rc.line2) ? String(rc.line2) : 'I want a lawyer.';
    var line3 = (rc && rc.line3) ? String(rc.line3) : 'I need an interpreter.';
    var piiReminder = (rc && rc.piiReminder) ? String(rc.piiReminder) : 'Do not include personal identifying information.';
    function esc(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    var html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' + esc(title) + '</title><style>body{font-family:system-ui,sans-serif;max-width:480px;margin:2rem auto;padding:2rem;font-size:1.25rem;line-height:1.6;color:#1a1d23;}h1{font-size:1.5rem;margin-bottom:0.5rem;}p{margin:0.75rem 0;}strong{margin-top:1rem;display:block;}</style></head><body><h1>' + esc(title) + '</h1><p>' + esc(subtitle) + '</p><p><strong>' + esc(line1) + '</strong></p><p><strong>' + esc(line2) + '</strong></p><p><strong>' + esc(line3) + '</strong></p><p><strong>' + esc(piiReminder) + '</strong></p></body></html>';
    var w = window.open('', '_blank');
    if (w) {
      w.document.write(html);
      w.document.close();
      w.focus();
      w.print();
    }
  }
  if (emergencyPrintCardBtn) {
    emergencyPrintCardBtn.addEventListener('click', openRightsCardPrint);
  }
})();
