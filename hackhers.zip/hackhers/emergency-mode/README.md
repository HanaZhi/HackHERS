# ICE Is at My Door Right Now — Emergency Mode

One-tap crisis interface for an immigration rights website. Mobile-first, React + Tailwind. No backend, no data storage, no analytics.

## Run locally

```bash
npm install
npm run dev
```

Open the URL shown (e.g. http://localhost:5173).

## Build

```bash
npm run build
```

Output is in `dist/`. Can be deployed as a static site or embedded in a parent site.

## Features

- **Home:** Single large red button: "ICE IS AT MY DOOR RIGHT NOW" → full-screen emergency mode.
- **Step 1:** "Take a breath. Stay calm." / "You do NOT have to open the door." / Next.
- **Step 2:** Ask to slide warrant under door; comparison cards (Judicial vs ICE administrative warrant); choices: No warrant / Yes warrant / Not sure → outcome screens.
- **Quick situations:** "They are inside already" / "I am outside" / "I am at work" → 3–5 bullet steps each.
- **Bottom bar:** Call Trusted Contact (opens phone), Know Your Rights (AILA link), Exit Emergency Mode.
- **Read Aloud:** Optional 🔊 button uses `speechSynthesis` (client-side only).
- **Disclaimer:** "This is general information only. Not legal advice."
- **Accessibility:** ARIA labels, dialog role, focus trap, Escape to exit, keyboard support.

## Tech

- React 18, Vite 5, Tailwind CSS 3.
- No external UI libraries. No backend. No storage.
