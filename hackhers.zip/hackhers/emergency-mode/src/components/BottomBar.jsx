/**
 * Persistent bottom bar in emergency mode: Call Trusted Contact, Know Your Rights, Exit.
 * Always visible; large tap targets.
 */
export default function BottomBar({ onExit }) {
  return (
    <footer
      className="fixed bottom-0 left-0 right-0 z-50 bg-slate-800 border-t border-slate-700 p-4 safe-area-pb"
      role="contentinfo"
      aria-label="Emergency actions"
    >
      <div className="max-w-lg mx-auto flex flex-col sm:flex-row gap-3">
        <a
          href="tel:"
          className="flex-1 py-4 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-center font-semibold text-lg focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="Call trusted contact"
        >
          Call Trusted Contact
        </a>
        <a
          href="https://www.aila.org/info/know-your-rights"
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-4 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-center font-semibold text-lg focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="Know your rights — opens in new tab"
        >
          Know Your Rights
        </a>
        <button
          type="button"
          onClick={onExit}
          className="flex-1 py-4 px-4 rounded-xl bg-slate-600 hover:bg-slate-500 text-center font-semibold text-lg focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="Exit emergency mode"
        >
          Exit Emergency Mode
        </button>
      </div>
    </footer>
  )
}
