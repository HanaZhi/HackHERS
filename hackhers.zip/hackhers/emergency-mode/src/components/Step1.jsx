/**
 * Step 1: Calm, short message. One "Next" button.
 */
import ReadAloudButton from './ReadAloudButton'

export default function Step1({ onNext }) {
  return (
    <section aria-labelledby="step1-heading" className="flex flex-col flex-1 justify-center">
      <h2 id="step1-heading" className="text-2xl font-bold mb-4">
        Take a breath. Stay calm.
      </h2>
      <p className="text-xl text-slate-200 mb-8">
        You do NOT have to open the door.
      </p>
      <div className="flex justify-end mb-4">
        <ReadAloudButton step="step1" />
      </div>
      <button
        type="button"
        onClick={onNext}
        className="w-full py-4 px-6 rounded-xl bg-white text-slate-900 text-lg font-bold focus:outline-none focus:ring-4 focus:ring-amber-400"
        aria-label="Next step"
      >
        Next
      </button>
    </section>
  )
}
