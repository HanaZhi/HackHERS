/**
 * Full-screen dark overlay. Contains step flow, quick situation panels, and read-aloud.
 * Minimal scrolling; large text and buttons.
 */
import { useRef, useEffect } from 'react'
import Step1 from './Step1'
import Step2 from './Step2'
import ResultScreen from './ResultScreen'
import QuickSituationPanel from './QuickSituationPanel'

export default function EmergencyOverlay({
  step,
  warrantChoice,
  quickSituation,
  onNext,
  onWarrantChoice,
  onQuickSituation,
  onBackToFlow,
  onExit,
}) {
  const overlayRef = useRef(null)

  // Focus trap and Escape key
  useEffect(() => {
    const el = overlayRef.current
    if (!el) return
    const focusables = el.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    )
    const first = focusables[0]
    const last = focusables[focusables.length - 1]
    if (first) first.focus()

    function handleKeyDown(e) {
      if (e.key === 'Escape') onExit()
      if (e.key !== 'Tab') return
      if (e.shiftKey) {
        if (document.activeElement === first) {
          e.preventDefault()
          last?.focus()
        }
      } else {
        if (document.activeElement === last) {
          e.preventDefault()
          first?.focus()
        }
      }
    }
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [onExit, step])

  return (
    <div
      ref={overlayRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="emergency-title"
      aria-live="assertive"
      className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col overflow-auto"
    >
      <h1 id="emergency-title" className="sr-only">Emergency guidance — ICE at the door</h1>
      <div className="flex-1 flex flex-col p-4 pb-28 max-w-lg mx-auto w-full">
        {step === 'step1' && (
          <Step1 onNext={onNext} />
        )}
        {step === 'step2' && (
          <Step2 onChoice={onWarrantChoice} onQuickSituation={onQuickSituation} />
        )}
        {step === 'result' && (
          <ResultScreen choice={warrantChoice} />
        )}
        {step === 'quick' && (
          <QuickSituationPanel situation={quickSituation} onBack={onBackToFlow} />
        )}
      </div>
    </div>
  )
}
