/**
 * Outcome screen based on warrant choice. Short bullets only.
 */
import ReadAloudButton from './ReadAloudButton'

const CONTENT = {
  no: {
    title: 'You do not have to open the door.',
    bullets: [
      'You do not have to open the door.',
      'You can remain silent.',
      'Do not sign anything.',
    ],
  },
  yes: {
    title: 'Stay calm.',
    bullets: [
      'Stay calm.',
      'Ask to see it fully.',
      'You have the right to remain silent.',
      'Ask to speak to a lawyer.',
    ],
  },
  unsure: {
    title: 'Only a judge-signed warrant allows entry without consent.',
    bullets: [
      'In general, only a warrant signed by a judge allows entry without consent.',
      "You can say: 'Please slide the warrant under the door.'",
    ],
  },
}

export default function ResultScreen({ choice }) {
  const data = CONTENT[choice] || CONTENT.unsure

  return (
    <section aria-labelledby="result-heading" className="flex flex-col">
      <div className="flex justify-end mb-2">
        <ReadAloudButton step="result" warrantChoice={choice} />
      </div>
      <h2 id="result-heading" className="text-xl font-bold mb-4">
        {data.title}
      </h2>
      <ul className="list-disc list-inside space-y-2 text-lg text-slate-200" aria-label="Guidance">
        {data.bullets.map((text, i) => (
          <li key={i}>{text}</li>
        ))}
      </ul>
    </section>
  )
}
