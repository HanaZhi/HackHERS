/**
 * Comparison card: Judicial vs ICE administrative warrant.
 * Clear labels so user can tell the difference.
 */
export default function WarrantCard({ title, description, variant }) {
  const isGood = variant === 'good'
  return (
    <div
      className={`p-4 rounded-xl border-2 ${
        isGood ? 'border-emerald-500 bg-emerald-950/40' : 'border-amber-600 bg-amber-950/30'
      }`}
      role="article"
      aria-label={title}
    >
      <h3 className="font-bold text-lg mb-2">{title}</h3>
      <p className="text-slate-300 text-sm leading-relaxed">{description}</p>
    </div>
  )
}
