/**
 * Read Aloud: uses browser speechSynthesis to speak current screen content.
 * No data sent anywhere. Client-side only.
 */
import { useState, useCallback } from 'react'

const STEP1_TEXT = 'Take a breath. Stay calm. You do not have to open the door.'
const STEP2_TEXT = 'Ask them to slide the warrant under the door. A judicial warrant is signed by a judge and has a court name. An ICE administrative warrant is not signed by a judge and does not allow them to enter without your permission.'

const RESULT_TEXTS = {
  no: 'You do not have to open the door. You can remain silent. Do not sign anything.',
  yes: 'Stay calm. Ask to see the warrant fully. You have the right to remain silent. Ask to speak to a lawyer.',
  unsure: 'In general, only a warrant signed by a judge allows entry without consent. You can say: Please slide the warrant under the door.',
}

const QUICK_TEXTS = {
  inside: 'They are inside already. Stay calm. Do not resist. You have the right to remain silent. Say: I want to speak to a lawyer. Do not sign anything. If possible, write down names and badge numbers.',
  outside: 'I am outside. You do not have to answer questions about your status. You can say: I choose to remain silent. Ask: Am I free to leave? If yes, leave calmly. You have the right to call a lawyer.',
  work: 'I am at work. Stay calm. You have the same rights at work. You do not have to answer questions about citizenship or status. You can say: I want to speak to a lawyer. Do not sign anything without a lawyer. If detained, ask to call your family and a lawyer.',
}

function getTextForScreen({ step, warrantChoice, quickSituation }) {
  if (step === 'step1') return STEP1_TEXT
  if (step === 'step2') return STEP2_TEXT
  if (step === 'result') return RESULT_TEXTS[warrantChoice] || RESULT_TEXTS.unsure
  if (step === 'quick') return QUICK_TEXTS[quickSituation] || QUICK_TEXTS.inside
  return ''
}

export default function ReadAloudButton({ step, warrantChoice = null, quickSituation = null }) {
  const [speaking, setSpeaking] = useState(false)

  const handleClick = useCallback(() => {
    const text = getTextForScreen({ step, warrantChoice, quickSituation })
    if (!text) return

    if (speaking) {
      window.speechSynthesis?.cancel()
      setSpeaking(false)
      return
    }

    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(text)
    u.rate = 0.9
    u.pitch = 1
    u.lang = 'en-US'
    u.onend = () => setSpeaking(false)
    u.onerror = () => setSpeaking(false)
    window.speechSynthesis.speak(u)
    setSpeaking(true)
  }, [step, warrantChoice, quickSituation, speaking])

  return (
    <button
      type="button"
      onClick={handleClick}
      className="py-2 px-4 rounded-lg bg-slate-700 hover:bg-slate-600 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-amber-400"
      aria-label={speaking ? 'Stop reading aloud' : 'Read this screen aloud'}
      aria-pressed={speaking}
    >
      {speaking ? '⏹ Stop' : '🔊 Read Aloud'}
    </button>
  )
}
