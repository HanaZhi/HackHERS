/**
 * Clear disclaimer: general information only, not legal advice.
 * Shown in emergency mode above the bottom bar.
 */
export default function Disclaimer() {
  return (
    <p
      className="fixed bottom-24 left-4 right-4 max-w-lg mx-auto z-40 text-xs text-slate-500 text-center"
      role="status"
      aria-live="polite"
    >
      This is general information only. Not legal advice.
    </p>
  )
}
