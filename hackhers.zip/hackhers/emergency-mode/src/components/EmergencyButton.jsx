/**
 * Large red homepage CTA. One tap enters emergency mode.
 * High contrast, impossible to miss.
 */
export default function EmergencyButton({ onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full max-w-md py-6 px-6 rounded-2xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white text-xl font-bold uppercase tracking-wide shadow-lg focus:outline-none focus:ring-4 focus:ring-red-400 focus:ring-offset-2 transition-colors"
      aria-label="ICE is at my door right now — open emergency guidance"
    >
      ICE IS AT MY DOOR RIGHT NOW
    </button>
  )
}
