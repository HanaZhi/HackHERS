/**
 * Quick situation: They are inside / I am outside / I am at work.
 * 3–5 bullet steps each. Back button to return to warrant flow.
 */
import ReadAloudButton from './ReadAloudButton'

const SITUATIONS = {
  inside: {
    title: 'They are inside already',
    bullets: [
      'Stay calm. Do not resist.',
      'You have the right to remain silent.',
      'Say: "I want to speak to a lawyer."',
      'Do not sign anything.',
      'If possible, write down names and badge numbers.',
    ],
  },
  outside: {
    title: 'I am outside',
    bullets: [
      'You do not have to answer questions about your status.',
      'You can say: "I choose to remain silent."',
      'Ask: "Am I free to leave?" If yes, leave calmly.',
      'You have the right to call a lawyer.',
    ],
  },
  work: {
    title: 'I am at work',
    bullets: [
      'Stay calm. You have the same rights at work.',
      'You do not have to answer questions about citizenship or status.',
      'You can say: "I want to speak to a lawyer."',
      'Do not sign anything without a lawyer.',
      'If detained, ask to call your family and a lawyer.',
    ],
  },
}

export default function QuickSituationPanel({ situation, onBack }) {
  const data = SITUATIONS[situation] || SITUATIONS.inside

  return (
    <section aria-labelledby="quick-heading" className="flex flex-col">
      <div className="flex justify-end mb-2">
        <ReadAloudButton step="quick" quickSituation={situation} />
      </div>
      <h2 id="quick-heading" className="text-xl font-bold mb-4">
        {data.title}
      </h2>
      <ul className="list-disc list-inside space-y-2 text-lg text-slate-200 mb-6" aria-label="Steps">
        {data.bullets.map((text, i) => (
          <li key={i}>{text}</li>
        ))}
      </ul>
      <button
        type="button"
        onClick={onBack}
        className="w-full py-3 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-lg font-semibold focus:outline-none focus:ring-4 focus:ring-amber-400"
        aria-label="Back to warrant question"
      >
        Back to warrant question
      </button>
    </section>
  )
}
