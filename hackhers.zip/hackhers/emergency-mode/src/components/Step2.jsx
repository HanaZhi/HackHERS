/**
 * Step 2: Warrant explanation, comparison cards, three choice buttons.
 * Plus quick situation links.
 */
import WarrantCard from './WarrantCard'
import ReadAloudButton from './ReadAloudButton'

export default function Step2({ onChoice, onQuickSituation }) {
  return (
    <section aria-labelledby="step2-heading" className="flex flex-col">
      <div className="flex justify-end mb-2">
        <ReadAloudButton step="step2" />
      </div>
      <h2 id="step2-heading" className="text-xl font-bold mb-3">
        Ask them to slide the warrant under the door.
      </h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <WarrantCard
          title="Judicial Warrant"
          description="Signed by a judge. Has a court name and judge signature."
          variant="good"
        />
        <WarrantCard
          title="ICE Administrative Warrant (I-200 / I-205)"
          description="NOT signed by a judge. Does NOT allow them to enter your home without your permission."
          variant="bad"
        />
      </div>

      <p className="text-slate-300 text-sm mb-4">
        Which best describes what they have?
      </p>

      <div className="space-y-3 mb-8">
        <button
          type="button"
          onClick={() => onChoice('no')}
          className="w-full py-4 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-left text-lg font-semibold focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="They do not have a judge-signed warrant"
        >
          They do NOT have a judge-signed warrant
        </button>
        <button
          type="button"
          onClick={() => onChoice('yes')}
          className="w-full py-4 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-left text-lg font-semibold focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="They do have a judge-signed warrant"
        >
          They DO have a judge-signed warrant
        </button>
        <button
          type="button"
          onClick={() => onChoice('unsure')}
          className="w-full py-4 px-4 rounded-xl bg-slate-700 hover:bg-slate-600 text-left text-lg font-semibold focus:outline-none focus:ring-4 focus:ring-amber-400"
          aria-label="I am not sure"
        >
          I am not sure
        </button>
      </div>

      {/* Quick situation buttons */}
      <p className="text-slate-400 text-sm mb-2">Different situation?</p>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => onQuickSituation('inside')}
          className="py-3 px-4 rounded-lg bg-slate-800 text-slate-200 text-base font-medium focus:outline-none focus:ring-2 focus:ring-amber-400"
          aria-label="They are inside already"
        >
          They are inside already
        </button>
        <button
          type="button"
          onClick={() => onQuickSituation('outside')}
          className="py-3 px-4 rounded-lg bg-slate-800 text-slate-200 text-base font-medium focus:outline-none focus:ring-2 focus:ring-amber-400"
          aria-label="I am outside"
        >
          I am outside
        </button>
        <button
          type="button"
          onClick={() => onQuickSituation('work')}
          className="py-3 px-4 rounded-lg bg-slate-800 text-slate-200 text-base font-medium focus:outline-none focus:ring-2 focus:ring-amber-400"
          aria-label="I am at work"
        >
          I am at work
        </button>
      </div>
    </section>
  )
}
