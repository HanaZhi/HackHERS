/**
 * ICE IS AT MY DOOR RIGHT NOW — Emergency Mode
 * One-tap crisis interface. No backend, no storage, no analytics.
 * Client-side only. Accessible, calm, minimal cognitive load.
 */
import { useState, useCallback, useEffect } from 'react'
import EmergencyButton from './components/EmergencyButton'
import EmergencyOverlay from './components/EmergencyOverlay'
import BottomBar from './components/BottomBar'
import Disclaimer from './components/Disclaimer'

export default function App() {
  const [isEmergencyMode, setIsEmergencyMode] = useState(false)
  const [step, setStep] = useState('step1') // 'step1' | 'step2' | 'result' | 'quick'
  const [warrantChoice, setWarrantChoice] = useState(null) // null | 'no' | 'yes' | 'unsure'
  const [quickSituation, setQuickSituation] = useState(null) // null | 'inside' | 'outside' | 'work'

  const enterEmergencyMode = useCallback(() => {
    setIsEmergencyMode(true)
    setStep('step1')
    setWarrantChoice(null)
    setQuickSituation(null)
  }, [])

  const exitEmergencyMode = useCallback(() => {
    setIsEmergencyMode(false)
    setStep('step1')
    setWarrantChoice(null)
    setQuickSituation(null)
  }, [])

  const goToStep2 = useCallback(() => setStep('step2'), [])
  const setResult = useCallback((choice) => {
    setWarrantChoice(choice)
    setStep('result')
  }, [])
  const showQuickSituation = useCallback((situation) => {
    setQuickSituation(situation)
    setStep('quick')
  }, [])
  const backToFlow = useCallback(() => {
    setQuickSituation(null)
    setStep('step2')
  }, [])

  // Lock body scroll when emergency mode is active
  useEffect(() => {
    if (isEmergencyMode) {
      document.body.classList.add('emergency-active')
    } else {
      document.body.classList.remove('emergency-active')
    }
    return () => document.body.classList.remove('emergency-active')
  }, [isEmergencyMode])

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col items-center justify-center p-4">
      {/* Home: single prominent CTA */}
      <main className="w-full max-w-lg text-center" role="main" aria-label="Home">
        <h1 className="text-xl font-semibold text-slate-800 mb-8">
          Know Your Rights
        </h1>
        <p className="text-slate-600 mb-6">
          If you need immediate help, tap below.
        </p>
        <EmergencyButton onClick={enterEmergencyMode} />
      </main>

      {/* Full-screen emergency takeover */}
      {isEmergencyMode && (
        <EmergencyOverlay
          step={step}
          warrantChoice={warrantChoice}
          quickSituation={quickSituation}
          onNext={goToStep2}
          onWarrantChoice={setResult}
          onQuickSituation={showQuickSituation}
          onBackToFlow={backToFlow}
          onExit={exitEmergencyMode}
        />
      )}

      {/* Persistent bottom bar and disclaimer only in emergency mode */}
      {isEmergencyMode && (
        <>
          <BottomBar onExit={exitEmergencyMode} />
          <Disclaimer />
        </>
      )}
    </div>
  )
}
