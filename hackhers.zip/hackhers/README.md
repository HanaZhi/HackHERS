# Know Your Rights — ICE & Immigration Information

A clean, informational website for people seeking factual information about ICE (U.S. Immigration and Customs Enforcement) and their rights. Not legal advice.

## What’s included

- **History** — Short history of ICE and why the agency was created  
- **Map** — Placeholder for where ICE operates / reported activity (you can add a real map or data source)  
- **News** — Section for neutral news updates (wire in RSS/API as needed)  
- **Who’s affected** — Overview of who may be affected by immigration enforcement  
- **Documents** — What documents help vs. don’t (with simple graphics)  
- **Naturalization** — Basic eligibility and links to USCIS  
- **Live chat** — Bottom-right button; opens a chat where users can ask things like “I have a driver’s license — does that help with ICE?” and get general, non-legal answers  

## How to run

Open `index.html` in a browser, or use a local server:

```bash
# Python 3
python3 -m http.server 8000

# Node (npx)
npx serve .
```

Then visit `http://localhost:8000` (or the port shown).

## Customization

- **Map:** Replace the placeholder in `#map-container` with Leaflet, Mapbox, or another map and your data source (e.g. ICE field offices, public reports).  
- **News:** Replace the sample cards in `#news-grid` with content from an RSS feed or API (e.g. NPR, Reuters, AP).  
- **Chat:** The chat in `script.js` uses simple keyword-based replies. You can plug in a real chat API or bot later.  
- **Copy:** Edit `index.html` to update any text, links, or sections.  
- **Styling:** Adjust colors and fonts in `styles.css` (CSS variables at the top).

## Disclaimer

This site is for general information only. It is not legal advice. Users should consult an immigration attorney or accredited representative for their situation.
