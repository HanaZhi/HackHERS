/**
 * Optional calming breathing animation before showing results. All labels translated.
 */

import React, { useState, useEffect } from 'react'
import { useLanguage } from '../i18n/LanguageContext'

const DURATION_MS = 6000

export default function BreathingPrompt({ onComplete, children }) {
  const { t } = useLanguage()
  const [phase, setPhase] = useState('idle')

  useEffect(() => {
    if (phase !== 'breathing') return
    const timer = setTimeout(() => {
      setPhase('done')
      onComplete?.()
    }, DURATION_MS)
    return () => clearTimeout(timer)
  }, [phase, onComplete])

  if (phase === 'idle') {
    return (
      <div className="breathing-prompt">
        <p className="breathing-prompt__intro">{t('breathing.intro')}</p>
        <button
          type="button"
          className="breathing-prompt__btn"
          onClick={() => setPhase('breathing')}
          aria-label={t('breathing.ariaStart')}
        >
          {t('breathing.ready')}
        </button>
      </div>
    )
  }

  if (phase === 'breathing') {
    return (
      <div className="breathing-prompt breathing-prompt--active">
        <div className="breathing-prompt__circle" aria-hidden="true" />
        <p className="breathing-prompt__label">{t('breathing.breatheLabel')}</p>
      </div>
    )
  }

  return children
}
