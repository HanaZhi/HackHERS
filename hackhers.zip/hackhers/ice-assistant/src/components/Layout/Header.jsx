/**
 * Header with app title and language toggle (top-right).
 * No login, no user data. Language persists in localStorage.
 */

import React from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

const LOCALE_LABELS = { en: 'EN', es: 'ES', zh_TW: '繁體中文' }

export default function Header() {
  const { locale, setLocale, t } = useLanguage()

  return (
    <header className="header">
      <div className="header__inner">
        <span className="header__logo">{t('appTitle')}</span>
        <div className="header__lang" role="group" aria-label="Language">
          {['en', 'es', 'zh_TW'].map((loc) => (
            <button
              key={loc}
              type="button"
              className={`header__lang-btn ${locale === loc ? 'header__lang-btn--active' : ''}`}
              onClick={() => setLocale(loc)}
              aria-pressed={locale === loc}
              aria-label={LOCALE_LABELS[loc]}
            >
              {LOCALE_LABELS[loc]}
            </button>
          ))}
        </div>
      </div>
    </header>
  )
}
