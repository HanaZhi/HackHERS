/**
 * Persistent footer with full disclaimer (translated) and privacy message.
 * No tracking. Global disclaimer required across the entire site.
 */

import React from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

export default function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="footer">
      <p className="footer__disclaimer">
        {t('disclaimers.footer')}
      </p>
      <p className="footer__text">
        {t('disclaimers.noLegalAdvice')}
      </p>
      <p className="footer__text footer__text--privacy">
        {t('privacy.weDoNotStore')}
      </p>
    </footer>
  )
}
