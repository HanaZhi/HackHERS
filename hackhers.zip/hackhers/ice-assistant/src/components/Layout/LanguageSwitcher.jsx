/**
 * Fixed floating language switcher — always visible so users can change
 * language without scrolling to the header. Placed bottom-left to avoid
 * overlapping the "Need help now" button (center).
 */

import React from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

const LOCALE_LABELS = { en: 'EN', es: 'ES', zh_TW: '繁體中文' }

export default function LanguageSwitcher() {
  const { locale, setLocale } = useLanguage()

  return (
    <div className="lang-float" role="group" aria-label="Language">
      <span className="lang-float__label">Language</span>
      <div className="lang-float__buttons">
        {['en', 'es', 'zh_TW'].map((loc) => (
          <button
            key={loc}
            type="button"
            className={`lang-float__btn ${locale === loc ? 'lang-float__btn--active' : ''}`}
            onClick={() => setLocale(loc)}
            aria-pressed={locale === loc}
            aria-label={LOCALE_LABELS[loc]}
          >
            {LOCALE_LABELS[loc]}
          </button>
        ))}
      </div>
    </div>
  )
}
