/**
 * "What do I do right now?" — Three tap-based emergency paths. All labels translated.
 */

import React, { useState } from 'react'
import { useLanguage } from '../../i18n/LanguageContext'
import { PATH_DOOR, PATH_STOPPED, PATH_DETAINED } from '../../data/emergencySteps'
import PathView from './PathView'

const PATHS = [
  { id: 'door', labelKey: 'emergencyFlow.door', data: PATH_DOOR },
  { id: 'stopped', labelKey: 'emergencyFlow.stopped', data: PATH_STOPPED },
  { id: 'detained', labelKey: 'emergencyFlow.detained', data: PATH_DETAINED },
]

export default function EmergencyFlow() {
  const { t } = useLanguage()
  const [activePath, setActivePath] = useState(null)

  return (
    <section className="block emergency-flow" aria-labelledby="emergency-flow-title">
      <h2 id="emergency-flow-title" className="block__title">{t('emergencyFlow.title')}</h2>
      <p className="block__lead">{t('emergencyFlow.lead')}</p>

      <div className="emergency-flow__buttons" role="group" aria-label={t('emergencyFlow.chooseSituation')}>
        {PATHS.map((path) => (
          <button
            key={path.id}
            type="button"
            className="emergency-flow__btn"
            onClick={() => setActivePath(activePath === path.id ? null : path.id)}
            aria-expanded={activePath === path.id}
            aria-controls={`path-${path.id}`}
          >
            {t(path.labelKey)}
          </button>
        ))}
      </div>

      {activePath && (
        <PathView
          id={activePath}
          path={PATHS.find((p) => p.id === activePath).data}
          onClose={() => setActivePath(null)}
        />
      )}
    </section>
  )
}
