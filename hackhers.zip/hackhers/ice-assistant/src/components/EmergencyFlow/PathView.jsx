/**
 * Step-by-step view for one emergency path. All text from translation keys.
 */

import React, { useState } from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

export default function PathView({ id, path, onClose }) {
  const { t } = useLanguage()
  const [stepIndex, setStepIndex] = useState(0)
  const steps = path.steps
  const current = steps[stepIndex]
  const isFirst = stepIndex === 0
  const isLast = stepIndex === steps.length - 1

  return (
    <div id={`path-${id}`} className="path-view" role="region" aria-labelledby={`path-title-${id}`}>
      <div className="path-view__header">
        <h3 id={`path-title-${id}`} className="path-view__title">{t(path.titleKey)}</h3>
        <button
          type="button"
          className="path-view__close"
          onClick={onClose}
          aria-label={t('common.close')}
        >
          ×
        </button>
      </div>

      <div className="path-view__reminder">
        <p>{t('path.rightsReminder')}</p>
      </div>

      <div className="path-view__step">
        <span className="path-view__step-num">{t('common.step')} {current.id}</span>
        <p className="path-view__step-text">{t(current.textKey)}</p>
        <p className="path-view__step-short">{t(current.shortKey)}</p>
      </div>

      <div className="path-view__nav">
        <button
          type="button"
          className="btn btn--secondary path-view__nav-btn"
          onClick={() => setStepIndex((i) => Math.max(0, i - 1))}
          disabled={isFirst}
          aria-label={t('common.previousStep')}
        >
          {t('common.previous')}
        </button>
        <span className="path-view__progress">
          {stepIndex + 1} {t('common.of')} {steps.length}
        </span>
        <button
          type="button"
          className="btn btn--primary path-view__nav-btn"
          onClick={() => setStepIndex((i) => (isLast ? onClose() : i + 1))}
          aria-label={isLast ? t('common.done') : t('common.nextStep')}
        >
          {isLast ? t('common.done') : t('common.next')}
        </button>
      </div>
    </div>
  )
}
