/**
 * Digital Emergency Plan — client-side only. All labels and PDF copy translated.
 * Form clears after download; nothing stored server-side.
 */

import React, { useState, useCallback } from 'react'
import { useLanguage } from '../../i18n/LanguageContext'
import { DOCUMENT_TYPES } from '../../utils/protectionLogic'
import { generateEmergencyPlanPdf } from '../../utils/pdfGenerator'

const US_STATES = [
  '', 'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
  'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa',
  'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan',
  'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio',
  'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia',
  'Wisconsin', 'Wyoming', 'District of Columbia',
]

const initialState = {
  contactFirstName: '',
  contactPhone: '',
  hasDependents: false,
  state: '',
  documentChecklist: [],
}

export default function EmergencyPlanForm() {
  const { t } = useLanguage()
  const [form, setForm] = useState(initialState)
  const [downloaded, setDownloaded] = useState(false)

  const update = useCallback((field, value) => {
    setForm((f) => ({ ...f, [field]: value }))
  }, [])

  const toggleDoc = useCallback((id) => {
    setForm((f) => ({
      ...f,
      documentChecklist: f.documentChecklist.includes(id)
        ? f.documentChecklist.filter((d) => d !== id)
        : [...f.documentChecklist, id],
    }))
  }, [])

  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault()
      const documentChecklistLabels = form.documentChecklist
        .map((id) => t(`documentTypes.${id}`))
        .filter(Boolean)
      const pdfStrings = {
        title: t('pdf.title'),
        generatedNotice: t('pdf.generatedNotice'),
        rightsTitle: t('pdf.rightsTitle'),
        right1: t('pdf.right1'),
        right2: t('pdf.right2'),
        right3: t('pdf.right3'),
        right4: t('pdf.right4'),
        contactTitle: t('pdf.contactTitle'),
        nameLabel: t('pdf.nameLabel'),
        phoneLabel: t('pdf.phoneLabel'),
        otherTitle: t('pdf.otherTitle'),
        stateLabel: t('pdf.stateLabel'),
        dependentsLabel: t('pdf.dependentsLabel'),
        yes: t('pdf.yes'),
        no: t('pdf.no'),
        documentsTitle: t('pdf.documentsTitle'),
        footerDisclaimer: t('pdf.footerDisclaimer'),
        footerPrivacy: t('pdf.footerPrivacy'),
        notProvided: t('pdf.notProvided'),
      }
      generateEmergencyPlanPdf(
        {
          contactFirstName: form.contactFirstName.trim(),
          contactPhone: form.contactPhone.trim(),
          hasDependents: form.hasDependents,
          state: form.state.trim(),
          documentChecklist: documentChecklistLabels,
        },
        pdfStrings
      )
      setDownloaded(true)
      setForm(initialState)
      setTimeout(() => setDownloaded(false), 4000)
    },
    [form, t]
  )

  return (
    <section className="block emergency-plan" aria-labelledby="emergency-plan-title">
      <h2 id="emergency-plan-title" className="block__title">{t('emergencyPlan.title')}</h2>
      <p className="block__lead">{t('emergencyPlan.lead')}</p>

      <p className="emergency-plan__privacy">{t('emergencyPlan.privacyNote')}</p>
      <p className="emergency-plan__minimize">{t('emergencyPlan.minimizeData')}</p>

      <form onSubmit={handleSubmit} className="emergency-plan__form">
        <label className="emergency-plan__label">
          {t('emergencyPlan.contactFirstName')}
          <input
            type="text"
            value={form.contactFirstName}
            onChange={(e) => update('contactFirstName', e.target.value)}
            placeholder={t('emergencyPlan.contactFirstNamePlaceholder')}
            className="emergency-plan__input"
            autoComplete="off"
          />
        </label>

        <label className="emergency-plan__label">
          {t('emergencyPlan.contactPhone')}
          <input
            type="tel"
            value={form.contactPhone}
            onChange={(e) => update('contactPhone', e.target.value)}
            placeholder={t('emergencyPlan.contactPhonePlaceholder')}
            className="emergency-plan__input"
            autoComplete="off"
          />
        </label>

        <label className="emergency-plan__label emergency-plan__label--checkbox">
          <input
            type="checkbox"
            checked={form.hasDependents}
            onChange={(e) => update('hasDependents', e.target.checked)}
            className="emergency-plan__checkbox"
          />
          {t('emergencyPlan.haveDependents')}
        </label>

        <label className="emergency-plan__label">
          {t('emergencyPlan.state')}
          <select
            value={form.state}
            onChange={(e) => update('state', e.target.value)}
            className="emergency-plan__select"
          >
            {US_STATES.map((s) => (
              <option key={s || 'blank'} value={s}>{s || '—'}</option>
            ))}
          </select>
        </label>

        <fieldset className="emergency-plan__fieldset">
          <legend className="emergency-plan__legend">{t('emergencyPlan.documentsLegend')}</legend>
          <div className="emergency-plan__checkboxes">
            {DOCUMENT_TYPES.filter((d) => d.id !== 'none_unsure').map((doc) => (
              <label key={doc.id} className="emergency-plan__label emergency-plan__label--checkbox">
                <input
                  type="checkbox"
                  checked={form.documentChecklist.includes(doc.id)}
                  onChange={() => toggleDoc(doc.id)}
                  className="emergency-plan__checkbox"
                />
                {t(`documentTypes.${doc.id}`)}
              </label>
            ))}
          </div>
        </fieldset>

        <button type="submit" className="btn btn--primary emergency-plan__submit">
          {t('emergencyPlan.downloadButton')}
        </button>
      </form>

      {downloaded && (
        <p className="emergency-plan__success" role="status">
          {t('emergencyPlan.successMessage')}
        </p>
      )}
    </section>
  )
}
