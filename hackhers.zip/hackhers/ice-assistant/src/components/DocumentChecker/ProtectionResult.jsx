/**
 * Displays protection explanation and next steps. All text from translation keys.
 * No user PII is shown or stored.
 */

import React from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

const LEVEL_KEYS = {
  strong: 'protection.levelStrong',
  some: 'protection.levelSome',
  limited: 'protection.levelLimited',
  rights: 'protection.levelRights',
}

export default function ProtectionResult({ result }) {
  const { t } = useLanguage()
  if (!result) return null

  const levelKey = LEVEL_KEYS[result.level] || 'protection.levelRights'
  const levelLabel = t(levelKey)

  return (
    <div className={`protection-result protection-result--${result.level}`} role="region" aria-labelledby="protection-result-title">
      <div className="protection-result__badge" aria-hidden="true">
        {levelLabel}
      </div>
      <h3 id="protection-result-title" className="protection-result__title">{t(result.titleKey)}</h3>
      <p className="protection-result__message">{t(result.messageKey)}</p>
      {result.nextStepKeys && result.nextStepKeys.length > 0 && (
        <div className="protection-result__next">
          <h4 className="protection-result__next-title">{t('protection.nextStepsTitle')}</h4>
          <ul className="protection-result__list">
            {result.nextStepKeys.map((key, i) => (
              <li key={i}>{t(key)}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}
