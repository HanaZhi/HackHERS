/**
 * Document-based protection checker. Checkboxes only — no uploads, no document numbers.
 * All assessment runs in the browser; nothing is sent to a server.
 * Shows "For informational purposes only" before results (translated).
 */

import React, { useState } from 'react'
import { useLanguage } from '../../i18n/LanguageContext'
import { DOCUMENT_TYPES, EXPIRATION_OPTIONS, getProtectionResult } from '../../utils/protectionLogic'
import ProtectionResult from './ProtectionResult'
import BreathingPrompt from '../BreathingPrompt'

export default function DocumentChecker() {
  const { t } = useLanguage()
  const [selectedDocs, setSelectedDocs] = useState([])
  const [expiration, setExpiration] = useState('')
  const [hasResult, setHasResult] = useState(false)

  const toggleDoc = (id) => {
    setSelectedDocs((prev) =>
      prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]
    )
    setHasResult(false)
  }

  const handleExpirationChange = (e) => {
    setExpiration(e.target.value)
    setHasResult(false)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setHasResult(true)
  }

  const result = hasResult && (selectedDocs.length > 0 || expiration)
    ? getProtectionResult(selectedDocs, expiration)
    : null

  return (
    <section className="block document-checker" aria-labelledby="doc-checker-title">
      <h2 id="doc-checker-title" className="block__title">{t('documentChecker.title')}</h2>
      <p className="block__lead">{t('documentChecker.lead')}</p>

      <form onSubmit={handleSubmit} className="doc-form">
        <fieldset className="doc-form__fieldset">
          <legend className="doc-form__legend">{t('documentChecker.legendDocs')}</legend>
          <div className="doc-form__checkboxes">
            {DOCUMENT_TYPES.map((doc) => (
              <label key={doc.id} className="doc-form__label">
                <input
                  type="checkbox"
                  checked={selectedDocs.includes(doc.id)}
                  onChange={() => toggleDoc(doc.id)}
                  className="doc-form__input"
                  aria-describedby="doc-privacy-note"
                />
                <span>{t(`documentTypes.${doc.id}`)}</span>
              </label>
            ))}
          </div>
        </fieldset>

        <fieldset className="doc-form__fieldset">
          <legend className="doc-form__legend">{t('documentChecker.legendExpiration')}</legend>
          <div className="doc-form__radios">
            {EXPIRATION_OPTIONS.map((opt) => (
              <label key={opt.id} className="doc-form__label">
                <input
                  type="radio"
                  name="expiration"
                  value={opt.id}
                  checked={expiration === opt.id}
                  onChange={handleExpirationChange}
                  className="doc-form__input"
                />
                <span>{t(`expiration.${opt.id}`)}</span>
              </label>
            ))}
          </div>
        </fieldset>

        <p id="doc-privacy-note" className="doc-form__privacy">
          {t('documentChecker.privacyNote')}
        </p>

        <button type="submit" className="btn btn--primary doc-form__submit">
          {t('documentChecker.submitButton')}
        </button>
      </form>

      {hasResult && result && (
        <>
          <p className="disclaimer-inline" role="note">
            {t('disclaimers.forInformationalOnly')}
          </p>
          <BreathingPrompt onComplete={() => {}}>
            <ProtectionResult result={result} />
          </BreathingPrompt>
        </>
      )}
    </section>
  )
}
