/**
 * Visible privacy statements. All copy from translations; reinforces local-only processing.
 */

import React from 'react'
import { useLanguage } from '../i18n/LanguageContext'

export default function PrivacyBanner() {
  const { t } = useLanguage()

  return (
    <div className="privacy-banner" role="status" aria-live="polite">
      <p className="privacy-banner__text">
        {t('privacy.platformNoStore')}
      </p>
      <p className="privacy-banner__text privacy-banner__text--strong">
        {t('privacy.weDoNotStore')}
      </p>
      <p className="privacy-banner__text privacy-banner__text--minimize">
        {t('privacy.minimizeData')}
      </p>
    </div>
  )
}
