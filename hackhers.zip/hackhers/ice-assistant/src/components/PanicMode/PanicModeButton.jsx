/**
 * Large "Need Help Now" button. Label translated.
 */

import React, { useState } from 'react'
import { useLanguage } from '../../i18n/LanguageContext'
import PanicModePanel from './PanicModePanel'

export default function PanicModeButton() {
  const { t } = useLanguage()
  const [open, setOpen] = useState(false)

  return (
    <>
      <button
        type="button"
        className="panic-btn"
        onClick={() => setOpen(true)}
        aria-label={t('nav.needHelpNow')}
        aria-expanded={open}
      >
        {t('nav.needHelpNow')}
      </button>
      {open && (
        <PanicModePanel onClose={() => setOpen(false)} />
      )}
    </>
  )
}
