/**
 * Panic panel: rights and key phrases. All text translated.
 */

import React from 'react'
import { useLanguage } from '../../i18n/LanguageContext'

const RIGHT_KEYS = ['panic.right1', 'panic.right2', 'panic.right3', 'panic.right4']
const PHRASE_KEYS = ['panic.phrase1', 'panic.phrase2']

export default function PanicModePanel({ onClose }) {
  const { t } = useLanguage()

  return (
    <div className="panic-panel" role="dialog" aria-labelledby="panic-panel-title" aria-modal="true">
      <div className="panic-panel__backdrop" onClick={onClose} aria-hidden="true" />
      <div className="panic-panel__content">
        <div className="panic-panel__header">
          <h2 id="panic-panel-title" className="panic-panel__title">{t('panic.yourRights')}</h2>
          <button
            type="button"
            className="panic-panel__close"
            onClick={onClose}
            aria-label={t('panic.ariaClose')}
          >
            ×
          </button>
        </div>

        <ul className="panic-panel__rights">
          {RIGHT_KEYS.map((key) => (
            <li key={key}>{t(key)}</li>
          ))}
        </ul>

        <div className="panic-panel__phrases">
          <p className="panic-panel__phrases-title">{t('panic.youCanSay')}</p>
          {PHRASE_KEYS.map((key) => (
            <p key={key} className="panic-panel__phrase">{t(key)}</p>
          ))}
        </div>

        <p className="panic-panel__reminder">{t('panic.emergencyReminder')}</p>

        <button type="button" className="btn btn--primary panic-panel__done" onClick={onClose}>
          {t('panic.readThis')}
        </button>
      </div>
    </div>
  )
}
