/**
 * Protection level assessment — CLIENT-SIDE ONLY.
 * Returns translation keys so UI can render in the user's language.
 * No PII is used or stored.
 */

export const DOCUMENT_TYPES = [
  { id: 'us_citizen' },
  { id: 'green_card' },
  { id: 'valid_visa' },
  { id: 'ead' },
  { id: 'daca_tps' },
  { id: 'i94' },
  { id: 'none_unsure' },
]

export const EXPIRATION_OPTIONS = [
  { id: 'valid' },
  { id: 'expired' },
  { id: 'unsure' },
]

const NEXT_STEP_KEYS_BASE = ['protection.next_1', 'protection.next_2', 'protection.next_3', 'protection.next_4']

/**
 * Returns protection result with translation keys (titleKey, messageKey, nextStepKeys).
 * Components use t() to resolve keys in the current locale.
 */
export function getProtectionResult(selectedDocIds, expirationId) {
  const primary = selectedDocIds[0]
  const isExpired = expirationId === 'expired'
  const isUnsure = expirationId === 'unsure'

  if (selectedDocIds.includes('us_citizen')) {
    return {
      level: 'strong',
      titleKey: 'protection.result_us_citizen_title',
      messageKey: 'protection.result_us_citizen_msg',
      nextStepKeys: NEXT_STEP_KEYS_BASE,
    }
  }

  if (selectedDocIds.includes('green_card')) {
    if (isExpired || isUnsure) {
      return {
        level: 'some',
        titleKey: 'protection.result_green_card_unsure_title',
        messageKey: 'protection.result_green_card_unsure_msg',
        nextStepKeys: [...NEXT_STEP_KEYS_BASE, 'protection.next_5'],
      }
    }
    return {
      level: 'strong',
      titleKey: 'protection.result_green_card_valid_title',
      messageKey: 'protection.result_green_card_valid_msg',
      nextStepKeys: NEXT_STEP_KEYS_BASE,
    }
  }

  if (selectedDocIds.includes('valid_visa') || selectedDocIds.includes('i94')) {
    if (isExpired) {
      return {
        level: 'limited',
        titleKey: 'protection.result_visa_expired_title',
        messageKey: 'protection.result_visa_expired_msg',
        nextStepKeys: [...NEXT_STEP_KEYS_BASE, 'protection.next_6'],
      }
    }
    if (isUnsure) {
      return {
        level: 'some',
        titleKey: 'protection.result_visa_unsure_title',
        messageKey: 'protection.result_visa_unsure_msg',
        nextStepKeys: NEXT_STEP_KEYS_BASE,
      }
    }
    return {
      level: 'strong',
      titleKey: 'protection.result_visa_valid_title',
      messageKey: 'protection.result_visa_valid_msg',
      nextStepKeys: NEXT_STEP_KEYS_BASE,
    }
  }

  if (selectedDocIds.includes('ead') || selectedDocIds.includes('daca_tps')) {
    if (isExpired) {
      return {
        level: 'some',
        titleKey: 'protection.result_ead_expired_title',
        messageKey: 'protection.result_ead_expired_msg',
        nextStepKeys: [...NEXT_STEP_KEYS_BASE, 'protection.next_7'],
      }
    }
    return {
      level: 'some',
      titleKey: 'protection.result_ead_valid_title',
      messageKey: 'protection.result_ead_valid_msg',
      nextStepKeys: NEXT_STEP_KEYS_BASE,
    }
  }

  if (primary === 'none_unsure' || selectedDocIds.length === 0) {
    return {
      level: 'rights',
      titleKey: 'protection.result_none_title',
      messageKey: 'protection.result_none_msg',
      nextStepKeys: NEXT_STEP_KEYS_BASE,
    }
  }

  return {
    level: 'some',
    titleKey: 'protection.result_fallback_title',
    messageKey: 'protection.result_fallback_msg',
    nextStepKeys: NEXT_STEP_KEYS_BASE,
  }
}
