/**
 * Client-side PDF generation only. No data is sent to any server.
 * Accepts optional translated strings so PDF matches the user's language.
 * We never store: A-numbers, passport numbers, SSN, addresses, or DOB.
 */

import { jsPDF } from 'jspdf'

const FONT_SIZE = 11
const LINE_HEIGHT = 6
const MARGIN = 20

const DEFAULT_STRINGS = {
  title: 'Emergency Plan — Know Your Rights',
  generatedNotice: 'This was generated on your device. No information was sent to or stored on any server.',
  rightsTitle: 'Rights reminder',
  right1: '• You have the right to remain silent.',
  right2: '• You have the right to speak to a lawyer.',
  right3: '• You do not have to open the door without a signed judicial warrant.',
  right4: '• Do not sign anything without understanding it.',
  contactTitle: 'Emergency contact',
  nameLabel: 'Name: ',
  phoneLabel: 'Phone: ',
  otherTitle: 'Other details',
  stateLabel: 'State: ',
  dependentsLabel: 'I have dependents: ',
  yes: 'Yes',
  no: 'No',
  documentsTitle: 'Documents I have (checklist)',
  footerDisclaimer: 'This is not legal advice. Consult an immigration attorney for your situation.',
  footerPrivacy: 'We do not store personal immigration data. All information stayed on your device.',
  notProvided: '(not provided)',
}

/**
 * Generates and downloads a PDF. All processing is local.
 * @param {Object} plan - { contactFirstName, contactPhone, hasDependents, state, documentChecklist }
 * @param {Object} [strings] - Translated PDF copy (pdf.* keys). Falls back to DEFAULT_STRINGS if omitted.
 */
export function generateEmergencyPlanPdf(plan, strings = {}) {
  const s = { ...DEFAULT_STRINGS, ...strings }
  const doc = new jsPDF({ format: 'letter', unit: 'pt' })
  let y = MARGIN + 20

  doc.setFontSize(16)
  doc.text(s.title, MARGIN, y)
  y += 24

  doc.setFontSize(10)
  doc.text(s.generatedNotice, MARGIN, y)
  y += LINE_HEIGHT * 2

  doc.setFontSize(12)
  doc.text(s.rightsTitle, MARGIN, y)
  y += LINE_HEIGHT + 2
  doc.setFontSize(FONT_SIZE)
  ;[s.right1, s.right2, s.right3, s.right4].forEach((line) => {
    doc.text(line, MARGIN, y)
    y += LINE_HEIGHT
  })
  y += 8

  doc.setFontSize(12)
  doc.text(s.contactTitle, MARGIN, y)
  y += LINE_HEIGHT + 2
  doc.setFontSize(FONT_SIZE)
  const name = (plan.contactFirstName || '').trim() ? plan.contactFirstName.trim() : s.notProvided
  const phone = (plan.contactPhone || '').trim() ? plan.contactPhone.trim() : s.notProvided
  doc.text(s.nameLabel + name, MARGIN, y)
  y += LINE_HEIGHT
  doc.text(s.phoneLabel + phone, MARGIN, y)
  y += LINE_HEIGHT + 8

  doc.setFontSize(12)
  doc.text(s.otherTitle, MARGIN, y)
  y += LINE_HEIGHT + 2
  doc.setFontSize(FONT_SIZE)
  doc.text(s.stateLabel + (plan.state || s.notProvided), MARGIN, y)
  y += LINE_HEIGHT
  doc.text(s.dependentsLabel + (plan.hasDependents ? s.yes : s.no), MARGIN, y)
  y += LINE_HEIGHT + 8

  if (plan.documentChecklist && plan.documentChecklist.length > 0) {
    doc.setFontSize(12)
    doc.text(s.documentsTitle, MARGIN, y)
    y += LINE_HEIGHT + 2
    doc.setFontSize(FONT_SIZE)
    plan.documentChecklist.forEach((label) => {
      doc.text('• ' + label, MARGIN, y)
      y += LINE_HEIGHT
    })
    y += 8
  }

  y += 16
  doc.setFontSize(10)
  doc.text(s.footerDisclaimer, MARGIN, y)
  y += LINE_HEIGHT * 2
  doc.text(s.footerPrivacy, MARGIN, y)

  const filename = 'emergency-plan-' + new Date().toISOString().slice(0, 10) + '.pdf'
  doc.save(filename)
}
