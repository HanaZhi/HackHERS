/**
 * Lightweight i18n: context-based language provider.
 * - No heavy external i18n lib; all strings from translations.js.
 * - Persists choice in localStorage so it survives refresh.
 * - Defaults to English; can auto-detect browser language once on first load.
 * - Missing key always falls back to English; app never crashes.
 */

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { translations, translate } from './translations'

const STORAGE_KEY = 'ice-assistant-lang'
const SUPPORTED = ['en', 'es', 'zh_TW']

function getStoredLanguage() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored && SUPPORTED.includes(stored)) return stored
  } catch (_) {}
  return null
}

/** Optional: detect browser language. Use only for initial load if nothing stored. */
function detectBrowserLanguage() {
  if (typeof navigator === 'undefined' || !navigator.language) return 'en'
  const lang = navigator.language
  if (lang.startsWith('es')) return 'es'
  if (lang.startsWith('zh')) {
    const region = (navigator.language || '').toUpperCase()
    if (region === 'ZH-TW' || region === 'ZH-HANT') return 'zh_TW'
    return 'zh_TW'
  }
  return 'en'
}

const LanguageContext = createContext(null)

export function LanguageProvider({ children }) {
  const [locale, setLocaleState] = useState(() => {
    const stored = getStoredLanguage()
    if (stored) return stored
    return detectBrowserLanguage()
  })

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, locale)
    } catch (_) {}
  }, [locale])

  useEffect(() => {
    const lang = locale === 'zh_TW' ? 'zh-Hant' : locale === 'es' ? 'es' : 'en'
    document.documentElement.lang = lang
  }, [locale])

  const setLocale = useCallback((next) => {
    if (SUPPORTED.includes(next)) setLocaleState(next)
  }, [])

  const t = useCallback(
    (path) => translate(locale, path),
    [locale]
  )

  const value = { locale, setLocale, t, supported: SUPPORTED }
  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider')
  return ctx
}
