/**
 * Emergency path config: translation keys only. No user data.
 * PathView and EmergencyFlow resolve keys via t() in the current locale.
 */

export const PATH_DOOR = {
  titleKey: 'path.door.title',
  steps: [
    { id: 1, textKey: 'path.door.step1', shortKey: 'path.door.step1Short' },
    { id: 2, textKey: 'path.door.step2', shortKey: 'path.door.step2Short' },
    { id: 3, textKey: 'path.door.step3', shortKey: 'path.door.step3Short' },
    { id: 4, textKey: 'path.door.step4', shortKey: 'path.door.step4Short' },
    { id: 5, textKey: 'path.door.step5', shortKey: 'path.door.step5Short' },
  ],
}

export const PATH_STOPPED = {
  titleKey: 'path.stopped.title',
  steps: [
    { id: 1, textKey: 'path.stopped.step1', shortKey: 'path.stopped.step1Short' },
    { id: 2, textKey: 'path.stopped.step2', shortKey: 'path.stopped.step2Short' },
    { id: 3, textKey: 'path.stopped.step3', shortKey: 'path.stopped.step3Short' },
    { id: 4, textKey: 'path.stopped.step4', shortKey: 'path.stopped.step4Short' },
    { id: 5, textKey: 'path.stopped.step5', shortKey: 'path.stopped.step5Short' },
  ],
}

export const PATH_DETAINED = {
  titleKey: 'path.detained.title',
  steps: [
    { id: 1, textKey: 'path.detained.step1', shortKey: 'path.detained.step1Short' },
    { id: 2, textKey: 'path.detained.step2', shortKey: 'path.detained.step2Short' },
    { id: 3, textKey: 'path.detained.step3', shortKey: 'path.detained.step3Short' },
    { id: 4, textKey: 'path.detained.step4', shortKey: 'path.detained.step4Short' },
    { id: 5, textKey: 'path.detained.step5', shortKey: 'path.detained.step5Short' },
  ],
}
