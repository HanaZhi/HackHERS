/**
 * ICE Encounter Safety Assistant — privacy-first, trauma-informed.
 * All UI text comes from i18n; language toggle in header.
 */

import React from 'react'
import { useLanguage } from './i18n/LanguageContext'
import Header from './components/Layout/Header'
import Footer from './components/Layout/Footer'
import PrivacyBanner from './components/PrivacyBanner'
import PanicModeButton from './components/PanicMode/PanicModeButton'
import LanguageSwitcher from './components/Layout/LanguageSwitcher'
import DocumentChecker from './components/DocumentChecker/DocumentChecker'
import EmergencyFlow from './components/EmergencyFlow/EmergencyFlow'
import EmergencyPlanForm from './components/EmergencyPlan/EmergencyPlanForm'

export default function App() {
  const { t, locale } = useLanguage()
  return (
    <div className={`app app--${locale}`}>
      <Header />
      <PrivacyBanner />

      <main className="main">
        <LanguageSwitcher />
        <div className="panic-btn-wrap">
          <PanicModeButton />
        </div>

        <div className="main__content">
          <section className="hero">
            <h1 className="hero__title">{t('hero.title')}</h1>
            <p className="hero__sub">{t('hero.sub')}</p>
          </section>

          <DocumentChecker />
          <EmergencyFlow />
          <EmergencyPlanForm />
        </div>
      </main>

      <Footer />
    </div>
  )
}
