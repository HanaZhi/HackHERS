# ICE Encounter Safety Assistant

Privacy-first, trauma-informed Real-Time ICE Encounter Safety Assistant for the Social Good track.

## Principles

- **Privacy-first:** No document uploads, no A-numbers, passport numbers, SSN, addresses, or DOB. No server storage of personal data. No login.
- **Client-side only:** All processing happens in the browser. Emergency plan PDF is generated locally and downloaded.
- **Trauma-informed UX:** Calm language, optional breathing animation before results, large buttons, minimal dense text.
- **Mobile-first:** Large tap targets, step-by-step flows.

## Features

1. **Document-based protection checker** — User selects document types (U.S. Citizen, Green Card, Visa, EAD, DACA/TPS, I-94, None/Unsure) and expiration status via checkboxes/radios only. System shows protection explanation and next steps. Optional breathing prompt before results.
2. **“What do I do right now?”** — Three paths: ICE at my door, Stopped outside, Detained. Step-by-step instructions, rights reminder, large buttons.
3. **Panic mode** — “Need help now” button opens a high-contrast panel with rights reminder, key phrases (“I choose to remain silent”, “I want a lawyer”), and emergency contact reminder.
4. **Digital emergency plan** — Optional inputs: emergency contact first name, phone, state (dropdown), dependents checkbox, document checklist. Generates a PDF on the client; form clears after download. No data sent to server.

## Run

```bash
npm install
npm run dev
```

Then open the URL shown (e.g. http://localhost:5173).

## Build

```bash
npm run build
```

Output is in `dist/`. Serve with any static host.

## File organization

```
src/
  components/
    Layout/          # Header, Footer
    PrivacyBanner.jsx # Visible “we don’t store data” text
    BreathingPrompt.jsx
    DocumentChecker/ # Checkboxes + protection result + optional breathing
    EmergencyFlow/  # Three paths + step view
    PanicMode/      # “Need help now” button + panel
    EmergencyPlan/  # Form + client-side PDF
  data/
    emergencySteps.js  # Static step content for door/stopped/detained
  utils/
    protectionLogic.js # Document type + expiration → message (no PII)
    pdfGenerator.js   # jsPDF client-side PDF; no server
  App.jsx
  main.jsx
  index.css
```

## Privacy

- No analytics or tracking in this template.
- No backend; no database. If you add a server later, do not send or store personal immigration identifiers.
- Visible messaging: “This platform does not store personal immigration identifiers. All information is processed locally on your device.” and “We do not store personal immigration data. All information stays on your device.”

## Disclaimer

This is not legal advice. Users should consult an immigration attorney for their situation.
