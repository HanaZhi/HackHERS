import React from 'react'
import ReactDOM from 'react-dom/client'
import { AccessibilityProvider } from './context/AccessibilityContext'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AccessibilityProvider>
      <App />
    </AccessibilityProvider>
  </React.StrictMode>
)
