/**
 * Header toggle: "Accessibility Mode". Persisted via context/localStorage.
 * When ON: larger base font, line spacing, high contrast, no animations, larger buttons, thicker borders.
 * Keyboard accessible; focus visible.
 */
import { useAccessibility } from "../context/AccessibilityContext";

export default function AccessibilityToggle() {
  const { accessibilityMode, setAccessibilityMode } = useAccessibility();

  return (
    <div className="flex items-center gap-2" role="group" aria-label="Accessibility">
      <label
        htmlFor="accessibility-toggle"
        className="text-sm font-medium text-slate-700 cursor-pointer select-none a11y:text-base"
      >
        Accessibility Mode
      </label>
      <button
        id="accessibility-toggle"
        type="button"
        role="switch"
        aria-checked={accessibilityMode}
        aria-label="Toggle accessibility mode"
        onClick={() => setAccessibilityMode(!accessibilityMode)}
        className="relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-slate-300 bg-slate-100 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 a11y:h-8 a11y:w-14 a11y:border-[3px]"
      >
        <span
          className="pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition-transform a11y:h-7 a11y:w-7"
          style={{
            transform: accessibilityMode ? 'translateX(1.75rem)' : 'translateX(0.125rem)',
          }}
        />
        <span className="sr-only">
          {accessibilityMode ? "Accessibility mode on" : "Accessibility mode off"}
        </span>
      </button>
    </div>
  );
}
