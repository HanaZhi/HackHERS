/**
 * "Built With Community Input" — 3 placeholder testimonial cards.
 * Quote, role, first name only. Trust-building; no fake logos or unverifiable claims.
 */
const TESTIMONIALS = [
  {
    quote:
      "Having clear, calm information in one place helps people know their options without feeling overwhelmed.",
    role: "Community Advocate",
    firstName: "Maria",
  },
  {
    quote:
      "Tools that explain rights in plain language support what we tell clients every day.",
    role: "Immigration Attorney",
    firstName: "James",
  },
  {
    quote:
      "When we can point people to something they can use on their phone right away, it makes a difference.",
    role: "Organizer",
    firstName: "Yuki",
  },
];

export default function CommunityValidation() {
  return (
    <section
      className="py-10 px-4"
      aria-labelledby="community-heading"
    >
      <h2
        id="community-heading"
        className="text-xl font-semibold text-slate-800 mb-2 text-center"
      >
        Built With Community Input
      </h2>
      <p className="text-sm text-slate-600 text-center mb-8 max-w-lg mx-auto">
        We collaborated with community advocates and reviewed publicly available
        legal guidance.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        {TESTIMONIALS.map((t, i) => (
          <div
            key={i}
            className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
          >
            <p className="text-slate-700 text-sm leading-relaxed mb-4">
              &ldquo;{t.quote}&rdquo;
            </p>
            <p className="text-xs font-semibold text-slate-800">{t.firstName}</p>
            <p className="text-xs text-slate-500">{t.role}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
