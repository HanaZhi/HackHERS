/**
 * Persistent legal disclaimer footer. Sticky at bottom; visible across site and in Emergency Mode.
 * Exact wording. Small but readable; high contrast; does not block main CTAs on mobile.
 */
export default function LegalDisclaimerFooter() {
  return (
    <footer
      className="sticky bottom-0 left-0 right-0 z-40 py-3 px-4 bg-slate-800 text-slate-200 border-t border-slate-700"
      role="contentinfo"
      aria-label="Legal disclaimer"
    >
      <p className="text-xs text-center max-w-2xl mx-auto leading-snug">
        This tool provides general educational information. It does not replace a
        lawyer or create an attorney-client relationship.
      </p>
    </footer>
  );
}
