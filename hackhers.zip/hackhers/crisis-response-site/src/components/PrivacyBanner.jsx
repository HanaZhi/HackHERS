/**
 * Prominent privacy statement near top of homepage.
 * Exact wording; shield icon; soft green background; ARIA status; mobile-first.
 */
export default function PrivacyBanner() {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex gap-3 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 max-w-3xl mx-auto"
    >
      <span className="flex-shrink-0 mt-0.5" aria-hidden="true">
        <svg
          className="w-6 h-6 text-emerald-600"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
          />
        </svg>
      </span>
      <p className="text-sm font-semibold leading-snug">
        We do NOT collect, store, or transmit personal immigration data. All
        information stays on your device.
      </p>
    </div>
  );
}
