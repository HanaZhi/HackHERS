/**
 * Shorter privacy line for footer. Same message, condensed.
 */
export default function PrivacyBannerShort() {
  return (
    <p className="text-xs text-slate-600" role="contentinfo">
      We do not collect, store, or transmit personal data. Everything stays on
      your device.
    </p>
  );
}
