/**
 * Site header: logo/title + Accessibility Mode toggle.
 * Accessible; focus states on toggle.
 */
import AccessibilityToggle from './AccessibilityToggle'

export default function Header() {
  return (
    <header
      className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-sm"
      role="banner"
    >
      <div className="max-w-4xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <a
          href="/"
          className="text-lg font-semibold text-teal-700 hover:text-teal-800 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 rounded a11y:text-xl a11y:py-1 a11y:px-1"
        >
          Know Your Rights
        </a>
        <AccessibilityToggle />
      </div>
    </header>
  )
}
