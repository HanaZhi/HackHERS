/**
 * Global accessibility mode state.
 * Persisted in localStorage. Used for larger text, high contrast, no animations.
 */
import { createContext, useContext, useState, useCallback, useEffect } from 'react'

const STORAGE_KEY = 'crisis-response-accessibility-mode'

const AccessibilityContext = createContext({
  accessibilityMode: false,
  setAccessibilityMode: () => {},
})

export function AccessibilityProvider({ children }) {
  const [accessibilityMode, setAccessibilityState] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      setAccessibilityState(stored === 'true')
    } catch (_) {}
    setMounted(true)
  }, [])

  const setAccessibilityMode = useCallback((value) => {
    setAccessibilityState(Boolean(value))
    try {
      if (value) localStorage.setItem(STORAGE_KEY, 'true')
      else localStorage.removeItem(STORAGE_KEY)
    } catch (_) {}
  }, [])

  useEffect(() => {
    if (!mounted) return
    if (accessibilityMode) {
      document.body.classList.add('accessibility-mode')
      document.documentElement.style.setProperty('color-scheme', 'high-contrast')
    } else {
      document.body.classList.remove('accessibility-mode')
      document.documentElement.style.removeProperty('color-scheme')
    }
  }, [accessibilityMode, mounted])

  return (
    <AccessibilityContext.Provider value={{ accessibilityMode, setAccessibilityMode }}>
      {children}
    </AccessibilityContext.Provider>
  )
}

export function useAccessibility() {
  const ctx = useContext(AccessibilityContext)
  if (!ctx) throw new Error('useAccessibility must be used within AccessibilityProvider')
  return ctx
}
