/**
 * Crisis-response site: trust, safety, accessibility, credibility.
 * Client-side only. No backend, no storage, no analytics.
 */
import Header from './components/Header'
import PrivacyBanner from './components/PrivacyBanner'
import CommunityValidation from './components/CommunityValidation'
import OpenSourceBadge from './components/OpenSourceBadge'
import PrivacyBannerShort from './components/PrivacyBannerShort'
import LegalDisclaimerFooter from './components/LegalDisclaimerFooter'

// Prop-driven source URL for Open Source section (set when repo is known)
const SOURCE_CODE_URL = import.meta.env.VITE_SOURCE_CODE_URL || 'https://github.com'

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 a11y:bg-white a11y:text-slate-900">
      <Header />

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-6 pb-8" role="main">
        {/* 1. Prominent privacy statement near top */}
        <div className="mb-8">
          <PrivacyBanner />
        </div>

        {/* Homepage content placeholder */}
        <section className="mb-10" aria-labelledby="intro-heading">
          <h1 id="intro-heading" className="text-2xl font-semibold text-slate-800 mb-3 a11y:text-3xl a11y:leading-relaxed">
            Immigration Rights & ICE Information
          </h1>
          <p className="text-slate-600 leading-relaxed a11y:text-lg a11y:leading-loose">
            Clear, factual information so you can stay informed and make decisions with confidence.
            Use the tools and links below to understand your rights and find resources.
          </p>
        </section>

        {/* 4. Community validation */}
        <CommunityValidation />
      </main>

      {/* Footer: short privacy + 2. Open Source section */}
      <footer className="border-t border-slate-200 bg-white mt-auto">
        <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
          <PrivacyBannerShort />
          <OpenSourceBadge sourceUrl={SOURCE_CODE_URL} />
        </div>
      </footer>

      {/* 5. Persistent legal disclaimer — sticky at bottom; visible in Emergency Mode too */}
      <LegalDisclaimerFooter />
    </div>
  )
}
