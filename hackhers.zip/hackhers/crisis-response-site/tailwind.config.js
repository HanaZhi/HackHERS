/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ["DM Sans", "system-ui", "sans-serif"] },
    },
  },
  plugins: [
    // Accessibility mode: when .accessibility-mode is on an ancestor, apply a11y: classes
    function ({ addVariant }) {
      addVariant("a11y", ".accessibility-mode &");
    },
  ],
};
