# Crisis-Response Site — Trust, Safety, Accessibility, Credibility

React + Tailwind. Client-side only. No backend, no storage, no analytics.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Optional: set GitHub (or other) source URL for the Open Source button:

```bash
VITE_SOURCE_CODE_URL=https://github.com/your-org/your-repo npm run build
```

---

## Component breakdown & placement

### 1. Privacy banner (prominent)

- **Components:** `PrivacyBanner.jsx`, `PrivacyBannerShort.jsx`
- **Placement:**  
  - **PrivacyBanner:** Near the top of the homepage, inside `<main>`, before other content.  
  - **PrivacyBannerShort:** In the footer, above or beside the Open Source section.
- **Text:** Exact wording as specified. Shield icon in banner. `role="status"` on the main banner.

### 2. Open Source badge

- **Component:** `OpenSourceBadge.jsx`
- **Props:** `sourceUrl` (default `'#'` or from `import.meta.env.VITE_SOURCE_CODE_URL`).
- **Placement:** Near footer, inside the same footer container as the short privacy line. Renders a section with GitHub icon, one short paragraph, and a “View Source Code” link.

### 3. Accessibility mode toggle

- **Context:** `context/AccessibilityContext.jsx` — `AccessibilityProvider`, `useAccessibility()`. Persists to `localStorage` key `crisis-response-accessibility-mode`.
- **Component:** `AccessibilityToggle.jsx` (switch with label “Accessibility Mode”).
- **Placement:** In the site header (`Header.jsx`), right side (or after logo/title). Wrap app in `AccessibilityProvider` in `main.jsx`.
- **When ON:** Body gets class `accessibility-mode`. Global CSS and Tailwind `a11y:` variant apply: larger base font, more line spacing, no animations, larger tap targets, thicker borders. `prefers-reduced-motion` respected in base CSS. Focus visible for keyboard.

### 4. Community validation section

- **Component:** `CommunityValidation.jsx`
- **Content:** Three placeholder testimonial cards (quote, role, first name only). One short note: “We collaborated with community advocates and reviewed publicly available legal guidance.”
- **Placement:** In `<main>`, after the main intro/content block. Responsive grid (1 col mobile, 3 col desktop).

### 5. Persistent legal disclaimer footer

- **Component:** `LegalDisclaimerFooter.jsx`
- **Placement:** Sticky at bottom of the viewport (`sticky bottom-0`). Rendered once at the end of the app so it stays visible on all views and in Emergency Mode. High contrast (dark bar, light text). Keep padding small so it doesn’t cover main CTAs on mobile.

---

## Layout integration (example)

```jsx
// main.jsx
<AccessibilityProvider>
  <App />
</AccessibilityProvider>

// App.jsx
<>
  <Header />                    {/* includes AccessibilityToggle */}
  <main>
    <PrivacyBanner />           {/* 1. near top */}
    {/* ... main content ... */}
    <CommunityValidation />     {/* 4. section */}
  </main>
  <footer>
    <PrivacyBannerShort />       {/* 1. short version */}
    <OpenSourceBadge sourceUrl={url} />  {/* 2. */}
  </footer>
  <LegalDisclaimerFooter />     {/* 5. sticky */}
</>
```

---

## Tailwind

- Custom variant `a11y:` in `tailwind.config.js`: `addVariant("a11y", ".accessibility-mode &")`. Use for accessibility-mode-only styles (e.g. `a11y:text-xl`).
- Base accessibility styles (font size, line height, no animations, min button size) live in `src/index.css` under `body.accessibility-mode`.

---

## Accessibility

- Privacy banner: `role="status"`.
- Toggle: `role="switch"`, `aria-checked`, `aria-label`.
- Footer/sections: `role="contentinfo"`, `aria-labelledby` where needed.
- Focus: `:focus-visible` in CSS; interactive elements use `focus:ring-2` (or equivalent) in Tailwind.
- No external libraries; semantics and ARIA kept in component code.
