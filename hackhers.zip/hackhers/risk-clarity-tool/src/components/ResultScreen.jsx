/**
 * Result: risk level + what protects you, what doesn't, what to say / not say, next steps.
 * Calm, clear, no jargon.
 */
import { LEVELS } from '../logic/riskCalculation'

const CONFIG = {
  [LEVELS.GREEN]: {
    label: 'Lower risk',
    heading: 'LOWER RISK',
    emoji: '🟢',
    bgClass: 'bg-emerald-50 border-emerald-200',
    headingClass: 'text-emerald-800',
    barClass: 'bg-emerald-500',
  },
  [LEVELS.YELLOW]: {
    label: 'Situational',
    heading: 'SITUATIONAL',
    emoji: '🟡',
    bgClass: 'bg-amber-50 border-amber-200',
    headingClass: 'text-amber-800',
    barClass: 'bg-amber-500',
  },
  [LEVELS.RED]: {
    label: 'Higher risk — seek legal help',
    heading: 'HIGHER RISK',
    sub: 'Seek legal help',
    emoji: '🔴',
    bgClass: 'bg-red-50 border-red-200',
    headingClass: 'text-red-800',
    barClass: 'bg-red-500',
  },
}

function Block({ title, items, className = '' }) {
  if (!items || items.length === 0) return null
  return (
    <div className={className}>
      <h3 className="text-sm font-semibold text-slate-700 uppercase tracking-wide mb-2">
        {title}
      </h3>
      <ul className="list-disc list-inside space-y-1 text-slate-700 text-sm">
        {items.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    </div>
  )
}

export default function ResultScreen({ result, onReset }) {
  const { level, protects, notProtects, sayThis, dontSay, nextSteps } = result
  const cfg = CONFIG[level] || CONFIG[LEVELS.YELLOW]

  return (
    <section aria-labelledby="result-heading" className="space-y-6">
      <div className={`rounded-xl border-2 p-4 ${cfg.bgClass}`}>
        <h2 id="result-heading" className={`text-lg font-bold ${cfg.headingClass}`}>
          {cfg.emoji} {cfg.heading}
          {cfg.sub && (
            <>
              <br />
              <span className="text-base font-semibold">{cfg.sub}</span>
            </>
          )}
        </h2>
      </div>

      <Block title="What helps protect you" items={protects} />
      <Block title="What does not protect you" items={notProtects} />
      <Block title="What you should say" items={sayThis} />
      <Block title="What you should NOT say or do" items={dontSay} />
      <Block title="Next steps" items={nextSteps} className="pt-2 border-t border-slate-200" />

      <button
        type="button"
        onClick={onReset}
        className="w-full py-3 px-4 rounded-xl border-2 border-slate-300 text-slate-700 font-semibold"
        aria-label="Start over"
      >
        Start over
      </button>
    </section>
  )
}
