/**
 * Step 2: What documents do you currently have? Multi-select.
 */
const OPTIONS = [
  { value: 'passport', label: 'U.S. Passport' },
  { value: 'greencard', label: 'Green Card' },
  { value: 'visa_i94', label: 'Valid Visa + I-94' },
  { value: 'ead', label: 'EAD (Work Permit)' },
  { value: 'i797', label: 'I-797 Approval Notice' },
  { value: 'state_id_only', label: 'State ID only' },
  { value: 'none', label: 'No documents on me' },
]

export default function StepDocuments({ value, onChange }) {
  const toggle = (docValue) => {
    if (docValue === 'none') {
      onChange(['none'])
      return
    }
    const next = value.includes(docValue)
      ? value.filter((d) => d !== docValue)
      : [...value.filter((d) => d !== 'none'), docValue]
    onChange(next.length ? next : [])
  }

  const isSelected = (v) => value.includes(v)

  return (
    <section aria-labelledby="documents-heading">
      <h2 id="documents-heading" className="text-lg font-semibold text-slate-800 mb-3">
        What documents do you currently have?
      </h2>
      <p className="text-slate-600 text-sm mb-4">Select all that apply.</p>
      <ul className="space-y-2" role="group" aria-label="Documents you have">
        {OPTIONS.map((opt) => (
          <li key={opt.value}>
            <button
              type="button"
              onClick={() => toggle(opt.value)}
              aria-pressed={isSelected(opt.value)}
              className={`w-full text-left py-4 px-4 rounded-xl border-2 transition-colors ${
                isSelected(opt.value)
                  ? 'border-teal-600 bg-teal-50 text-slate-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
              }`}
            >
              <span className="inline-flex items-center gap-2">
                <span
                  className={`inline-block w-5 h-5 rounded border-2 flex-shrink-0 ${
                    isSelected(opt.value) ? 'bg-teal-600 border-teal-600' : 'border-slate-300'
                  }`}
                  aria-hidden
                >
                  {isSelected(opt.value) && (
                    <svg className="w-full h-full text-white p-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  )}
                </span>
                {opt.label}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  )
}
