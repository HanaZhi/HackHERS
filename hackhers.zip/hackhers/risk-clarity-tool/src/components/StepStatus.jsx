/**
 * Step 3: What is your current status? Single select.
 */
const OPTIONS = [
  { value: 'citizen', label: 'U.S. Citizen' },
  { value: 'lpr', label: 'Lawful Permanent Resident' },
  { value: 'temporary', label: 'Temporary Status (DACA / TPS / etc.)' },
  { value: 'visa_holder', label: 'Visa Holder' },
  { value: 'undocumented', label: 'Undocumented' },
  { value: 'unsure', label: 'Unsure' },
]

export default function StepStatus({ value, onChange }) {
  return (
    <section aria-labelledby="status-heading">
      <h2 id="status-heading" className="text-lg font-semibold text-slate-800 mb-3">
        What is your current status?
      </h2>
      <ul className="space-y-2" role="listbox" aria-label="Choose one">
        {OPTIONS.map((opt) => (
          <li key={opt.value}>
            <button
              type="button"
              onClick={() => onChange(opt.value)}
              role="option"
              aria-selected={value === opt.value}
              className={`w-full text-left py-4 px-4 rounded-xl border-2 transition-colors ${
                value === opt.value
                  ? 'border-teal-600 bg-teal-50 text-slate-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
              }`}
            >
              {opt.label}
            </button>
          </li>
        ))}
      </ul>
    </section>
  )
}
