/**
 * Step 1: Where are you right now? Single select.
 */
const OPTIONS = [
  { value: 'home', label: 'Inside my home' },
  { value: 'outside', label: 'Outside in public' },
  { value: 'work', label: 'At work' },
  { value: 'driving', label: 'Driving' },
]

export default function StepLocation({ value, onChange }) {
  return (
    <section aria-labelledby="location-heading">
      <h2 id="location-heading" className="text-lg font-semibold text-slate-800 mb-3">
        Where are you right now?
      </h2>
      <ul className="space-y-2" role="listbox" aria-label="Choose one">
        {OPTIONS.map((opt) => (
          <li key={opt.value}>
            <button
              type="button"
              onClick={() => onChange(opt.value)}
              role="option"
              aria-selected={value === opt.value}
              className={`w-full text-left py-4 px-4 rounded-xl border-2 transition-colors ${
                value === opt.value
                  ? 'border-teal-600 bg-teal-50 text-slate-900'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
              }`}
            >
              {opt.label}
            </button>
          </li>
        ))}
      </ul>
    </section>
  )
}
