/**
 * Disclaimer at bottom. Not legal advice.
 */
export default function Disclaimer() {
  return (
    <footer className="mt-auto py-4 px-4 border-t border-slate-200 bg-white">
      <p className="text-xs text-slate-500 text-center max-w-lg mx-auto" role="contentinfo">
        This is general information only. It is not legal advice. Your situation may vary.
        For legal advice, please contact an immigration attorney or accredited representative.
      </p>
    </footer>
  )
}
