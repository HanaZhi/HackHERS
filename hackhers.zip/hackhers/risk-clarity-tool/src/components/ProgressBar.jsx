/**
 * Progress bar at top. Shows step N of 3. Calm, minimal.
 */
export default function ProgressBar({ current, total }) {
  const pct = Math.round((current / total) * 100)
  return (
    <div className="w-full bg-slate-200 h-1.5" role="progressbar" aria-valuenow={current} aria-valuemin={1} aria-valuemax={total} aria-label={`Step ${current} of ${total}`}>
      <div
        className="h-full bg-teal-600 transition-all duration-300"
        style={{ width: `${pct}%` }}
      />
    </div>
  )
}
