/**
 * What's My Situation? — Personalized Risk Clarity Tool
 * Client-side only. No data stored. Not legal advice.
 */
import { useState, useCallback } from 'react'
import { calculateRisk } from './logic/riskCalculation'
import ProgressBar from './components/ProgressBar'
import StepLocation from './components/StepLocation'
import StepDocuments from './components/StepDocuments'
import StepStatus from './components/StepStatus'
import ResultScreen from './components/ResultScreen'
import Disclaimer from './components/Disclaimer'

const STEPS = ['location', 'documents', 'status']
const TOTAL_STEPS = STEPS.length

export default function App() {
  const [stepIndex, setStepIndex] = useState(0)
  const [location, setLocation] = useState(null)
  const [documents, setDocuments] = useState([])
  const [status, setStatus] = useState(null)

  const step = STEPS[stepIndex]
  const showResult = stepIndex >= TOTAL_STEPS

  const goNext = useCallback(() => {
    if (stepIndex < TOTAL_STEPS - 1) setStepIndex((i) => i + 1)
    else setStepIndex(TOTAL_STEPS)
  }, [stepIndex])

  const goBack = useCallback(() => {
    setStepIndex((i) => Math.max(0, i - 1))
  }, [])

  const reset = useCallback(() => {
    setStepIndex(0)
    setLocation(null)
    setDocuments([])
    setStatus(null)
  }, [])

  const result = showResult && location && status
    ? calculateRisk(location, documents, status)
    : null

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {!showResult && (
        <ProgressBar current={stepIndex + 1} total={TOTAL_STEPS} />
      )}

      <main className="flex-1 max-w-lg mx-auto w-full px-4 py-6 pb-24">
        <h1 className="text-xl font-semibold text-slate-800 mb-2">
          What's My Situation?
        </h1>
        <p className="text-slate-600 text-sm mb-6">
          Answer a few quick questions. Takes under a minute. Nothing is saved.
        </p>

        {step === 'location' && (
          <StepLocation value={location} onChange={setLocation} />
        )}
        {step === 'documents' && (
          <StepDocuments value={documents} onChange={setDocuments} />
        )}
        {step === 'status' && (
          <StepStatus value={status} onChange={setStatus} />
        )}

        {showResult && result && (
          <ResultScreen result={result} onReset={reset} />
        )}

        {!showResult && (
          <div className="flex gap-3 mt-8">
            {stepIndex > 0 && (
              <button
                type="button"
                onClick={goBack}
                className="py-3 px-5 rounded-xl border border-slate-300 text-slate-700 font-medium"
                aria-label="Back"
              >
                Back
              </button>
            )}
            <button
              type="button"
              onClick={goNext}
              disabled={step === 'status' ? !status : step === 'location' ? !location : false}
              className="flex-1 py-3 px-5 rounded-xl bg-teal-600 text-white font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={stepIndex === TOTAL_STEPS - 1 ? 'See my result' : 'Next'}
            >
              {stepIndex === TOTAL_STEPS - 1 ? 'See my result' : 'Next'}
            </button>
          </div>
        )}
      </main>

      <Disclaimer />
    </div>
  )
}
