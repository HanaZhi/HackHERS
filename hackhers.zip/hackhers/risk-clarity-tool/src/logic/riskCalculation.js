/**
 * Risk Clarity Tool — decision logic.
 * Readable logic tree. No legal advice. Client-side only; no data stored.
 *
 * Risk levels:
 * - green: Lower risk (documentation shows lawful status)
 * - yellow: Situational (depends on circumstances)
 * - red: Higher risk — seek legal help
 */

const LEVELS = { GREEN: 'green', YELLOW: 'yellow', RED: 'red' }

// Document keys as used in the UI
const DOC = {
  PASSPORT: 'passport',
  GREENCARD: 'greencard',
  VISA_I94: 'visa_i94',
  EAD: 'ead',
  I797: 'i797',
  STATE_ID_ONLY: 'state_id_only',
  NONE: 'none',
}

const STATUS = {
  CITIZEN: 'citizen',
  LPR: 'lpr',
  TEMPORARY: 'temporary',
  VISA_HOLDER: 'visa_holder',
  UNDOCUMENTED: 'undocumented',
  UNSURE: 'unsure',
}

/** True if user has at least one strong proof-of-status document on them */
function hasStrongDoc(documents) {
  return (
    documents.includes(DOC.PASSPORT) ||
    documents.includes(DOC.GREENCARD) ||
    documents.includes(DOC.VISA_I94)
  )
}

/** True if user has some work/approval doc (EAD, I-797) */
function hasWorkOrApprovalDoc(documents) {
  return documents.includes(DOC.EAD) || documents.includes(DOC.I797)
}

/** True if user has no documents or only state ID */
function hasNoMeaningfulDocs(documents) {
  if (documents.length === 0) return true
  const onlyStateOrNone =
    documents.every((d) => d === DOC.STATE_ID_ONLY || d === DOC.NONE) ||
    documents.includes(DOC.NONE)
  return onlyStateOrNone
}

/**
 * Returns { level, protects, notProtects, sayThis, dontSay, nextSteps }
 */
export function calculateRisk(location, documents, status) {
  const result = {
    level: LEVELS.YELLOW,
    protects: [],
    notProtects: [],
    sayThis: [],
    dontSay: [],
    nextSteps: [],
  }

  // ——— U.S. Citizen ———
  if (status === STATUS.CITIZEN) {
    result.level = LEVELS.GREEN
    result.protects = [
      'U.S. citizenship is your strongest protection.',
      'A U.S. passport or citizenship proof shows you have the right to be here.',
    ]
    result.notProtects = [
      'Showing a state ID only does not prove citizenship. If asked about status, you can show a passport or say you are a citizen if you have proof at home.',
    ]
    result.sayThis = [
      '"I am a U.S. citizen."',
      '"I have the right to remain silent."',
      '"I would like to speak to a lawyer if this continues."',
    ]
    result.dontSay = ['Do not lie. Do not pretend you do not speak English if you do.']
    result.nextSteps = [
      'Keep a passport or citizenship document accessible if possible.',
      'You have the right to remain silent.',
      'Stay calm.',
    ]
    return result
  }

  // ——— Lawful Permanent Resident (Green Card) ———
  if (status === STATUS.LPR) {
    if (documents.includes(DOC.GREENCARD) || documents.includes(DOC.PASSPORT)) {
      result.level = LEVELS.GREEN
      result.protects = [
        'Your green card (or passport if naturalized) shows lawful permanent residence.',
        'You have the right to be in the U.S. and to work.',
      ]
      result.notProtects = [
        'A state ID or driver’s license alone does not prove immigration status.',
      ]
      result.sayThis = [
        '"I am a lawful permanent resident."',
        '"I have the right to remain silent."',
        '"I want to speak to a lawyer before answering more."',
      ]
      result.dontSay = ['Do not sign anything that could waive your rights.']
      result.nextSteps = [
        'Keep your green card accessible.',
        'Remain calm.',
        'You have the right to remain silent and to ask for a lawyer.',
      ]
    } else {
      result.level = LEVELS.YELLOW
      result.protects = [
        'Your lawful permanent resident status protects you even if you do not have the card on you.',
      ]
      result.notProtects = [
        'Without the card on you, you may be asked more questions until your status can be verified.',
      ]
      result.sayThis = [
        '"I am a lawful permanent resident. I do not have my card with me."',
        '"I have the right to remain silent."',
        '"I want to speak to a lawyer."',
      ]
      result.dontSay = ['Do not sign any document without speaking to a lawyer.']
      result.nextSteps = [
        'Carry your green card when you can.',
        'Remain calm. Ask for a lawyer if questioned.',
        'Do not answer questions about how you entered or your immigration history without a lawyer.',
      ]
    }
    return result
  }

  // ——— Temporary status (DACA, TPS, etc.) ———
  if (status === STATUS.TEMPORARY) {
    result.level = hasWorkOrApprovalDoc(documents) || hasStrongDoc(documents) ? LEVELS.YELLOW : LEVELS.YELLOW
    result.protects = [
      'Your approval notice or work permit shows you have temporary lawful status.',
      'You have the right to remain silent and to ask for a lawyer.',
    ]
    result.notProtects = [
      'Temporary status can change with policy. Your documents show current permission to be here.',
      'A state ID alone does not prove immigration status.',
    ]
    result.sayThis = [
      '"I have authorization to be in the United States."',
      '"I choose to remain silent."',
      '"I want to speak to a lawyer."',
    ]
    result.dontSay = [
      'Do not sign anything without a lawyer.',
      'Do not answer questions about your entry or family without a lawyer.',
    ]
    result.nextSteps = [
      'Keep your EAD or approval notice accessible when possible.',
      'Stay informed about your category and any renewal deadlines.',
      'If questioned, say you want to remain silent and want a lawyer.',
    ]
    return result
  }

  // ——— Visa holder ———
  if (status === STATUS.VISA_HOLDER) {
    if (documents.includes(DOC.VISA_I94)) {
      result.level = LEVELS.YELLOW
      result.protects = [
        'Your valid visa and I-94 show you are here with permission.',
        'You have the right to remain silent and to ask for a lawyer.',
      ]
      result.notProtects = [
        'Visa status can be sensitive. Stay within the terms of your visa.',
      ]
      result.sayThis = [
        '"I am here on a valid visa."',
        '"I have the right to remain silent."',
        '"I want to speak to a lawyer."',
      ]
      result.dontSay = ['Do not sign anything without a lawyer.']
      result.nextSteps = [
        'Keep your visa and I-94 accessible when traveling.',
        'Remain calm. You have the right to remain silent and to a lawyer.',
      ]
    } else {
      result.level = LEVELS.YELLOW
      result.protects = ['You have the right to remain silent and to ask for a lawyer.']
      result.notProtects = [
        'Without your visa and I-94 on you, it may be harder to show you are here lawfully.',
      ]
      result.sayThis = [
        '"I am a visa holder. I do not have my documents with me."',
        '"I choose to remain silent."',
        '"I want to speak to a lawyer."',
      ]
      result.dontSay = ['Do not sign anything without a lawyer.']
      result.nextSteps = [
        'Carry your visa and I-94 when you can.',
        'Ask for a lawyer if questioned. Remain silent if you prefer.',
      ]
    }
    return result
  }

  // ——— Undocumented ———
  if (status === STATUS.UNDOCUMENTED) {
    result.level = LEVELS.RED
    result.protects = [
      'You have the right to remain silent.',
      'You have the right to ask for a lawyer.',
      'You do not have to open the door at home unless they have a warrant signed by a judge.',
    ]
    result.notProtects = [
      'A state ID, driver’s license, or other non-immigration documents do not prove immigration status or protect from enforcement.',
    ]
    result.sayThis = [
      '"I choose to remain silent."',
      '"I want a lawyer."',
      '"I need an interpreter." (if you need one)',
    ]
    result.dontSay = [
      'Do not answer questions about where you were born or your immigration status.',
      'Do not sign anything without a lawyer.',
      'Do not open the door at home unless they slide a judge-signed warrant under the door.',
    ]
    result.nextSteps = [
      'Do not answer questions about your status.',
      'Ask for a lawyer immediately.',
      'Do not sign anything.',
      'Seek legal help from an immigration attorney or nonprofit as soon as you can.',
    ]
    return result
  }

  // ——— Unsure ———
  if (status === STATUS.UNSURE) {
    if (hasStrongDoc(documents)) {
      result.level = LEVELS.YELLOW
      result.protects = [
        'The documents you have may show lawful presence. Only an attorney can confirm your status.',
        'You have the right to remain silent and to ask for a lawyer.',
      ]
      result.notProtects = [
        'We cannot tell you your legal status. This is not legal advice.',
      ]
      result.sayThis = [
        '"I want to speak to a lawyer before answering."',
        '"I choose to remain silent."',
      ]
      result.dontSay = ['Do not guess your status. Do not sign anything without a lawyer.']
      result.nextSteps = [
        'Speak to an immigration attorney or accredited representative to understand your status.',
        'Until then, you have the right to remain silent and to ask for a lawyer.',
      ]
    } else {
      result.level = LEVELS.RED
      result.protects = [
        'You have the right to remain silent.',
        'You have the right to ask for a lawyer.',
      ]
      result.notProtects = [
        'Without knowing your status, we cannot say what protects you. A state ID or no documents does not show immigration status.',
      ]
      result.sayThis = [
        '"I choose to remain silent."',
        '"I want a lawyer."',
      ]
      result.dontSay = [
        'Do not answer questions about your status or place of birth.',
        'Do not sign anything.',
      ]
      result.nextSteps = [
        'Do not answer questions about your status.',
        'Ask for a lawyer.',
        'Do not sign anything.',
        'Seek legal help to understand your situation.',
      ]
    }
    return result
  }

  return result
}

export { LEVELS, DOC, STATUS }
