# What's My Situation? — Risk Clarity Tool

Interactive “Personalized Risk Clarity Tool” for an immigration rights website. Helps users quickly understand how protected they may be and what their next best step is. Client-side only; no data stored.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Flow

1. **Step 1 — Where are you right now?**  
   Inside my home / Outside in public / At work / Driving

2. **Step 2 — What documents do you currently have?** (multi-select)  
   U.S. Passport, Green Card, Valid Visa + I-94, EAD, I-797, State ID only, No documents on me

3. **Step 3 — What is your current status?**  
   U.S. Citizen / Lawful Permanent Resident / Temporary (DACA/TPS/etc.) / Visa Holder / Undocumented / Unsure

4. **Result**  
   - Risk level: 🟢 Lower risk / 🟡 Situational / 🔴 Higher risk — seek legal help  
   - What protects you | What does not | What you should say | What you should NOT say | Next steps  

Progress bar at top. Disclaimer at bottom. Not legal advice.

## Tech

- React 18, Vite 5, Tailwind CSS 3
- Logic in `src/logic/riskCalculation.js` (readable decision tree)
- No backend, no storage, no analytics
