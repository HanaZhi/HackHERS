/**
 * Final screen after all scenarios. Reinforces that they know the basics.
 */
export default function FinalScreen({ onReviewRights, onReturnHome }) {
  return (
    <section className="text-center space-y-6" aria-labelledby="final-heading">
      <h2 id="final-heading" className="text-xl font-semibold text-slate-800">
        You now know the basics of your rights.
      </h2>
      <p className="text-slate-600 text-sm">
        Remember: you have the right to remain silent, the right to a lawyer, and you do not have to sign anything without legal advice.
      </p>

      <div className="flex flex-col gap-3 pt-4">
        <button
          type="button"
          onClick={onReviewRights}
          className="w-full py-4 px-4 rounded-xl bg-teal-600 text-white font-semibold hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
          aria-label="Review my rights — opens in new tab"
        >
          Review my rights
        </button>
        <button
          type="button"
          onClick={onReturnHome}
          className="w-full py-4 px-4 rounded-xl border-2 border-slate-300 text-slate-700 font-semibold hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
          aria-label="Return home"
        >
          Return home
        </button>
      </div>
    </section>
  )
}
