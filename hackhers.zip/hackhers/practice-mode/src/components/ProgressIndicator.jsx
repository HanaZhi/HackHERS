/**
 * Progress: "Scenario 1 of 3". Calm, minimal.
 */
export default function ProgressIndicator({ current, total }) {
  return (
    <p
      className="text-sm text-slate-500 mb-6"
      aria-live="polite"
      aria-label={`Scenario ${current} of ${total}`}
    >
      Scenario {current} of {total}
    </p>
  )
}
