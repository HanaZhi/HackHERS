/**
 * One scenario: prompt, choices, then feedback after selection.
 * Large tap targets. Immediate feedback.
 */
export default function ScenarioStep({
  scenario,
  selectedChoiceId,
  selectedChoice,
  onChoice,
  onNext,
  hasSelected,
  isLast,
}) {
  return (
    <section aria-labelledby="scenario-prompt" className="space-y-6">
      <div className="rounded-xl bg-white border border-slate-200 p-5 shadow-sm">
        <p
          id="scenario-prompt"
          className="text-lg text-slate-800 font-medium leading-snug mb-6"
        >
          {scenario.prompt}
        </p>

        {!hasSelected ? (
          <ul className="space-y-3" role="group" aria-label="What would you do?">
            {scenario.choices.map((choice) => (
              <li key={choice.id}>
                <button
                  type="button"
                  onClick={() => onChoice(choice.id)}
                  className="w-full text-left py-4 px-4 rounded-xl border-2 border-slate-200 bg-white text-slate-800 font-medium hover:border-teal-500 hover:bg-teal-50/50 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
                  aria-pressed={false}
                >
                  {choice.label}
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <>
            <div
              className={`rounded-xl border-2 p-4 mb-6 ${
                selectedChoice.correct
                  ? 'border-emerald-500 bg-emerald-50'
                  : 'border-amber-500 bg-amber-50'
              }`}
              role="status"
              aria-live="polite"
            >
              <p className="text-sm font-semibold text-slate-700 mb-1">
                {selectedChoice.correct ? 'Good choice' : 'Here’s what to know'}
              </p>
              <p className="text-slate-700 text-sm leading-relaxed">
                {selectedChoice.feedback}
              </p>
            </div>

            <button
              type="button"
              onClick={onNext}
              className="w-full py-4 px-4 rounded-xl bg-teal-600 text-white font-semibold hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2"
              aria-label={isLast ? 'Finish and see summary' : 'Try another scenario'}
            >
              {isLast ? 'Finish' : 'Try another scenario'}
            </button>
          </>
        )}
      </div>
    </section>
  )
}
