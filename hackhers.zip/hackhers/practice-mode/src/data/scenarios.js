/**
 * Practice Mode — scenario data.
 * Each scenario: prompt, choices (id, label, correct, feedback).
 * Educational only. Reinforces: right to remain silent, don't sign, ask for lawyer.
 */

export const scenarios = [
  {
    id: 'home',
    title: 'At home',
    prompt: 'You hear a knock at your door. Someone says they are from ICE.',
    choices: [
      {
        id: 'open',
        label: 'Open the door immediately.',
        correct: false,
        feedback:
          'Opening the door may allow officers to enter. You are not required to open the door unless they have a warrant signed by a judge. You have the right to remain silent and to ask for a lawyer.',
      },
      {
        id: 'warrant',
        label: 'Ask them to slide a judicial warrant under the door.',
        correct: true,
        feedback:
          'You are not required to open the door unless they show a warrant signed by a judge. Asking to see the warrant helps you know your options. You have the right to remain silent. Do not sign anything without a lawyer.',
      },
      {
        id: 'silent',
        label: 'Say nothing and stay inside.',
        correct: false,
        feedback:
          'You can stay silent. It is better to ask them to slide the warrant under the door so you can check if it is signed by a judge. Only a judicial warrant (signed by a judge) can require you to open the door. You have the right to remain silent and to ask for a lawyer.',
      },
    ],
  },
  {
    id: 'public',
    title: 'In public',
    prompt: 'Someone approaches you in public and says they are from ICE. They ask where you were born.',
    choices: [
      {
        id: 'answer',
        label: 'Answer the question.',
        correct: false,
        feedback:
          'You do not have to answer questions about your status or where you were born. You have the right to remain silent. You can say you want to speak to a lawyer. Do not sign anything.',
      },
      {
        id: 'silent_leave',
        label: "Say: \"I choose to remain silent. Am I free to leave?\"",
        correct: true,
        feedback:
          'You have the right to remain silent. Asking if you are free to leave is a clear way to understand the situation. If they say yes, you may leave calmly. If not, repeat that you want to remain silent and want a lawyer. Do not sign anything.',
      },
      {
        id: 'lawyer',
        label: "Say: \"I want to speak to a lawyer.\"",
        correct: false,
        feedback:
          'Asking for a lawyer is good. It is also helpful to say you choose to remain silent and to ask, "Am I free to leave?" You do not have to answer questions about your status. Do not sign anything.',
      },
    ],
  },
  {
    id: 'work',
    title: 'At work',
    prompt: 'ICE officers come to your workplace and ask to speak with you. They ask about your immigration status.',
    choices: [
      {
        id: 'answer',
        label: 'Answer their questions.',
        correct: false,
        feedback:
          'You do not have to answer questions about your status, even at work. You have the right to remain silent and the right to a lawyer. Do not sign anything. Say you want to speak to a lawyer before answering.',
      },
      {
        id: 'lawyer',
        label: "Say: \"I want to speak to a lawyer before answering.\"",
        correct: true,
        feedback:
          'You have the right to a lawyer. You do not have to answer questions about your status. Do not sign anything. Stay calm. You can keep saying you want to remain silent and want a lawyer.',
      },
      {
        id: 'refuse_leave',
        label: 'Refuse to talk and leave the building.',
        correct: false,
        feedback:
          'You have the right to remain silent. It is better to clearly say you want a lawyer rather than leaving without saying anything. Say: "I want to speak to a lawyer. I am not answering questions." Do not sign anything.',
      },
    ],
  },
]
