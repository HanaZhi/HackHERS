/**
 * Practice an ICE Encounter — simulator.
 * Client-side only. No data stored. Educational, calm tone.
 */
import { useState, useCallback } from 'react'
import { scenarios } from './data/scenarios'
import ProgressIndicator from './components/ProgressIndicator'
import ScenarioStep from './components/ScenarioStep'
import FinalScreen from './components/FinalScreen'
import Disclaimer from './components/Disclaimer'

const TOTAL = scenarios.length

export default function App() {
  const [scenarioIndex, setScenarioIndex] = useState(0)
  const [selectedChoiceId, setSelectedChoiceId] = useState(null)
  const [showFinal, setShowFinal] = useState(false)

  const scenario = scenarios[scenarioIndex]
  const selectedChoice = scenario?.choices.find((c) => c.id === selectedChoiceId)
  const hasSelected = selectedChoiceId != null

  const handleChoice = useCallback((choiceId) => {
    setSelectedChoiceId(choiceId)
  }, [])

  const handleNextScenario = useCallback(() => {
    setSelectedChoiceId(null)
    if (scenarioIndex + 1 >= TOTAL) {
      setShowFinal(true)
    } else {
      setScenarioIndex((i) => i + 1)
    }
  }, [scenarioIndex])

  const handleReturnHome = useCallback(() => {
    window.location.href = '/'
  }, [])

  const handleReviewRights = useCallback(() => {
    window.open('https://www.aila.org/info/know-your-rights', '_blank', 'noopener,noreferrer')
  }, [])

  if (showFinal) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <main className="flex-1 max-w-lg mx-auto w-full px-4 py-8">
          <FinalScreen onReviewRights={handleReviewRights} onReturnHome={handleReturnHome} />
        </main>
        <Disclaimer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <main className="flex-1 max-w-lg mx-auto w-full px-4 py-6 pb-24">
        <h1 className="text-xl font-semibold text-slate-800 mb-1">
          Practice an ICE Encounter
        </h1>
        <p className="text-slate-600 text-sm mb-6">
          Choose what you would do. No wrong answers — we'll explain what helps protect your rights.
        </p>

        <ProgressIndicator current={scenarioIndex + 1} total={TOTAL} />

        <ScenarioStep
          scenario={scenario}
          selectedChoiceId={selectedChoiceId}
          selectedChoice={selectedChoice}
          onChoice={handleChoice}
          onNext={handleNextScenario}
          hasSelected={hasSelected}
          isLast={scenarioIndex + 1 >= TOTAL}
        />
      </main>

      <Disclaimer />
    </div>
  )
}
