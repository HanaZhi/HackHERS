# Practice an ICE Encounter

Interactive practice mode for an immigration rights website. Users rehearse scenarios (at home, in public, at work), choose an action, and get calm, educational feedback. Client-side only; no data stored.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Flow

1. **Progress:** "Scenario 1 of 3"
2. **Scenario:** Prompt + 2–3 choices (large buttons)
3. **Feedback:** After selection — "Good choice" or "Here's what to know" + short explanation (right to remain silent, don't sign, ask for lawyer)
4. **Next:** "Try another scenario" → Scenario 2, then 3
5. **Final:** "You now know the basics of your rights." + **Review my rights** (opens AILA) + **Return home**
6. **Disclaimer:** "For educational purposes only. Not legal advice."

## Scenarios (data in `src/data/scenarios.js`)

- **At home:** Knock at door, ICE. Choices: Open door / Ask for judicial warrant / Say nothing. Correct: Ask for warrant.
- **In public:** Approach, "Where were you born?" Choices: Answer / Remain silent + "Am I free to leave?" / Ask for lawyer. Correct: Remain silent + free to leave.
- **At work:** ICE at workplace, ask about status. Choices: Answer / Ask for lawyer / Refuse and leave. Correct: Ask for lawyer.

## Tech

- React 18, Vite 5, Tailwind CSS 3
- No backend, no storage, no external libraries
